import './style.css'
import * as THREE from 'three'

export function setup() {
  const canvasElement = document.getElementById('frontpage-3d-scene')

  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(30, canvasElement.offsetWidth / canvasElement.offsetHeight, 0.1, 1000)

  const renderer = new THREE.WebGLRenderer({
    canvas: canvasElement,
    alpha: true,
  })

  renderer.setPixelRatio(window.devicePixelRatio)
  renderer.setSize(canvasElement.offsetWidth, canvasElement.offsetHeight)
  renderer.setClearColor(0x0a0a0a, 0)

  camera.position.setZ(100)

  const geometry = new THREE.SphereGeometry(24, 32, 16)
  const material = new THREE.MeshBasicMaterial({ color: 0x818cf8, wireframe: true })

  const shape = new THREE.Mesh(geometry, material)

  scene.add(shape)

  function animate() {
    requestAnimationFrame(animate)

    shape.rotateY(1)

    renderer.render(scene, camera)
  }
  animate()
}

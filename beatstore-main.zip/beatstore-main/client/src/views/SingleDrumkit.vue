<template>
  <div>
    <div class="pb-6 pt-4 bg-grey mb-4 rounded-regular">
      <h2 class="text-center">{{ drumkit.title }}</h2>
      <img src="" alt="" />
    </div>
    <div>
      <div v-for="directory in drumkit.directories" :key="directory.title" class="mb-8">
        <p class="text-xl">{{ directory.title }}</p>
        <div class="flex flex-col gap-4">
          <div v-for="drum in directory.drums" :key="drum.title" class="flex ml-8 border p-2">
            <button @click="toggleAudio(directory.title, drum.title, drum.audio.url)">
              <PlayIcon v-if="!isThatDrumPlaying(directory.title, drum.title)" size="24" />
              <PauseIcon v-else size="24" />
            </button>
            <p>{{ drum.type }}</p>
            <p>{{ drum.title }}</p>
          </div>
        </div>
      </div>
    </div>
    <div class="grid grid-cols-4 grid-rows-2 items-center justify-center gap-4">
      <div class="row-span-2 flex flex-col items-center justify-center gap-4">
        <span>{{ drumkit.price.value }} {{ drumkit.price.currency }}</span>
        <button class="base-btn">Buy</button>
        <button class="base-btn bg-red-500">Delete</button>
      </div>
      <Likes @like="likeDrumkit" :totalLikes="drumkit.totalLikes" :isLiked="drumkit.isLiked"></Likes>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
import Likes from '../components/Likes.vue'
import PlayIcon from '../components/icons/Play.vue'
import PauseIcon from '../components/icons/Pause.vue'

export default {
  components: {
    Likes,
    PlayIcon,
    PauseIcon,
  },
  data() {
    return {
      drumkit: null,
      currentlyPlaying: {
        directoryTitle: '',
        drumTitle: '',
        audio: null,
        isPaused: false,
      },
    }
  },
  methods: {
    isThatDrumPlaying(directoryTitle, drumTitle) {
      if (
        this.currentlyPlaying.drumTitle === drumTitle &&
        this.currentlyPlaying.directoryTitle === directoryTitle &&
        !this.currentlyPlaying.isPaused
      ) {
        return true
      }
      return false
    },
    toggleAudio(directoryTitle, drumTitle, url) {
      if (!this.$store.state.currentlyPlaying.isPaused) {
        this.$store.commit('setCurrentlyPlaying', { isPaused: true })
      }

      if (!this.currentlyPlaying.audio) {
        const audio = new Audio(url)
        audio.play()

        this.currentlyPlaying = {
          directoryTitle,
          drumTitle,
          audio,
          isPaused: false,
        }
      } else if (this.currentlyPlaying.directoryTitle === directoryTitle && this.currentlyPlaying.drumTitle === drumTitle) {
        if (this.currentlyPlaying.audio.paused) {
          this.currentlyPlaying.audio.play()
          this.currentlyPlaying.isPaused = false
        } else {
          this.currentlyPlaying.audio.pause()
          this.currentlyPlaying.isPaused = true
        }
      } else {
        if (!this.currentlyPlaying.audio.paused) this.currentlyPlaying.audio.pause()

        const audio = new Audio(url)
        audio.play()

        this.currentlyPlaying = {
          drumTitle,
          directoryTitle,
          audio,
          isPaused: false,
        }
      }
    },
    async likeDrumkit() {
      //send request to the server
      const res = await axios.post(this.$store.state.serverUrl + '/drumkits/' + this.drumkit._id + '/like')

      if (res.statusText !== 'OK') {
        //an error occured
      }
      //client side (increment by one and turn isLiked to true)
      if (!this.drumkit.isLiked) {
        this.drumkit.isLiked = true
        this.drumkit.totalLikes++
      } else {
        this.drumkit.isLiked = false
        this.drumkit.totalLikes--
      }
    },
    async getDrumkit() {
      const { id } = this.$route.params
      const res = await axios.get(this.serverUrl + '/drumkits/' + id)

      if (res.statusText !== 'OK') {
        //an error occured
      }

      console.log(res)

      this.drumkit = res.data.drumkit
    },
    async deleteBeat() {
      try {
        //delete from database
        await axios.delete(this.serverUrl + '/drumkits', {
          data: {
            drumkitId: this.drumkit._id,
          },
        })

        this.$router.push('/')
      } catch (error) {
        console.log(error)
      }
    },
    async editDrumkit() {
      //todo
      return

      try {
        const { title, bpm, key, genre, _id } = this.drumkit

        const res = await axios.patch(this.serverUrl + '/beats', {
          _id,
          title,
          bpm,
          key,
          genre,
          audioUrl: this.editedBeat.audio.url,
        })

        if (res.statusText !== 'OK') {
          //error bad response
        }
        Object.assign(this.beat, res.data.beat)
      } catch (error) {
        console.log(error)
      }
    },
  },
  computed: {
    serverUrl() {
      return this.$store.state.serverUrl
    },
    token() {
      return this.$store.state.token
    },
  },
  created() {
    this.getDrumkit()
  },
}
</script>

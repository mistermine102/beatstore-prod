<template>
  <div class="flex flex-col items-center justify-center">
    <h2 class="base-heading">Log in</h2>
    <form class="flex flex-col p-4 w-1/2" @submit.prevent="login">
      <div class="mb-4">
        <input v-model="user.email" type="text" placeholder="Email" class="base-input w-full" />
        <p v-if="v$.user.email.$error" class="base-error-msg">{{ v$.user.email.$errors[0].$message }}</p>
      </div>
      <div :class="[!error && 'mb-4']">
        <input v-model="user.password" type="password" placeholder="Password" class="base-input w-full" />
        <p v-if="v$.user.password.$error" class="base-error-msg">{{ v$.user.password.$errors[0].$message }}</p>
      </div>
      <p v-if="error" class="base-error-msg mb-4">{{ error }}</p>
      <BaseButton :isLoading="isLoading">Continue</BaseButton>
    </form>
    <div>
      <p>You don't have an account? <router-link class="base-link" to="/register">Sign up now</router-link></p>
    </div>
  </div>
</template>

<script>
import BaseButton from '../components/base/BaseButton.vue'

import axios from 'axios'
import { useVuelidate } from '@vuelidate/core'
import { required, email, helpers } from '@vuelidate/validators'

export default {
  components: {
    BaseButton,
  },
  setup() {
    return {
      v$: useVuelidate(),
    }
  },
  data() {
    return {
      error: null,
      isLoading: false,
      user: {
        email: '',
        password: '',
      },
    }
  },
  validations() {
    return {
      user: {
        email: {
          required: helpers.withMessage('Email is required', required),
          email: helpers.withMessage('Invalid email', email),
        },
        password: {
          required: helpers.withMessage('Password is required', required),
        },
      },
    }
  },
  methods: {
    async login() {
      try {
        this.isLoading = true
        this.v$.$validate()

        if (this.v$.$error) {
          return
        }

        const res = await axios.post(this.$store.state.serverUrl + '/login', this.user)

        if (res.statusText !== 'OK') {
          return
        }

        const { user, token } = res.data

        this.$store.dispatch('login', {
          user,
          token,
        })
      } catch (error) {
        this.error = error.response.data.message
      } finally {
        this.isLoading = false
      }
    },
  },
}
</script>

<template>
  <div class="flex flex-col items-center justify-center">
    <h2 class="base-heading">Log in</h2>
    <form class="flex flex-col gap-4 p-4 w-1/2" @submit.prevent="login">
      <div class="">
        <input v-model="user.email" type="text" placeholder="email" class="base-input w-full" />
        <p class=""></p>
      </div>
      <input v-model="user.password" type="text" placeholder="password" class="base-input" />
      <button class="base-btn">Continue</button>
    </form>
    <div>
      <p>You don't have an account? <router-link class="base-link" to="/register">Sign up now</router-link></p>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      user: {
        email: '',
        password: '',
      },
      errors: {
        email: null,
        passwort: null,
      },
    }
  },
  methods: {
    async login() {
      const res = await axios.post(this.$store.state.serverUrl + '/login', this.user)

      if (res.statusText !== 'OK') {
        //error occured
        throw new Error('INVALID RESPONSE')
      }

      const { user, token } = res.data

      this.$store.dispatch('login', {
        user,
        token,
      })
    },
  },
}
</script>

<template>
  <div>
    <SelectTrack @selectTrack="continueToUpload"></SelectTrack>
    <div v-if="selectedTrackType" :selectedTrackType="selectedTrackType">
      <UploadBeat v-if="selectedTrackType === 'Beat'"></UploadBeat>
      <UploadSample v-if="selectedTrackType === 'Sample'"></UploadSample>
      <UploadDrumkit v-if="selectedTrackType === 'Drumkit'"></UploadDrumkit>
    </div>
  </div>
</template>
<script>
import SelectTrack from '../components/upload/SelectTrack.vue'
import UploadBeat from '../components/upload/beat/UploadBeat.vue'
import UploadSample from '../components/upload/sample/UploadSample.vue'
import UploadDrumkit from '../components/upload/drumkit/UploadDrumkit.vue'

export default {
  data() {
    return {
      selectedTrackType: null,
    }
  },
  components: {
    SelectTrack,
    UploadBeat,
    UploadSample,
    UploadDrumkit,
  },
  methods: {
    continueToUpload(trackType) {
      this.selectedTrackType = trackType
    },
  },
}
</script>

<template>
  <div>
    <div class="pb-6 pt-4 bg-grey mb-4 rounded-regular">
      <h2 class="text-center">{{ beat.title }}</h2>
      <img v-if="beat.image" :src="beat.image.url" alt="Beat image" />
    </div>
    <p class="text-center mb-4">3:17</p>
    <div class="h-[150px] flex justify-center items-center bg-grey mb-8 rounded-regular">
      <PlayPauseBtn :track="beat"></PlayPauseBtn>
    </div>
    <div class="grid grid-cols-4 grid-rows-2 items-center justify-center gap-4">
      <p>
        <span>BPM</span> <span>{{ beat.bpm.toUpperCase() }}</span>
      </p>
      <p>
        <span>KEY</span> <span>{{ beat.key.toUpperCase() }}</span>
      </p>
      <p>
        <span>GENRE</span> <span>{{ beat.genre.toUpperCase() }}</span>
      </p>
      <div class="row-span-2 flex flex-col items-center justify-center gap-4">
        <span>{{ beat.price.value }} {{ beat.price.currency }}</span>
        <button class="base-btn">Buy</button>
        <button @click="deleteBeat" class="base-btn bg-red-500">Delete</button>
      </div>
      <span class="flex gap-2"> <PlayIcon strokeWidth="1.5" size="24" />{{ beat.totalStreams }}</span>
      <Likes @like="likeBeat" :totalLikes="beat.totalLikes" :isLiked="beat.isLiked"></Likes>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
import PlayIcon from '../components/icons/Play.vue'
import Likes from '../components/Likes.vue'
import PlayPauseBtn from '../components/track/PlayPauseBtn.vue'

export default {
  components: {
    PlayIcon,
    Likes,
    PlayPauseBtn,
  },
  data() {
    return {
      beat: null,
    }
  },
  methods: {
    async likeBeat() {
      //send request to the server
      const res = await axios.post(this.$store.state.serverUrl + '/beats/' + this.beat._id + '/like')

      if (res.statusText !== 'OK') {
        //an error occured
      }
      //client side (increment by one and turn isLiked to true)
      if (!this.beat.isLiked) {
        this.beat.isLiked = true
        this.beat.totalLikes++
      } else {
        this.beat.isLiked = false
        this.beat.totalLikes--
      }
    },
    async getBeat() {
      const { id } = this.$route.params
      const res = await axios.get(this.serverUrl + '/beats/' + id)

      if (res.statusText !== 'OK') {
        //an error occured
      }

      this.beat = res.data.beat
    },
    async deleteBeat() {
      try {
        //delete from database
        await axios.delete(this.serverUrl + '/beats', {
          data: {
            beatId: this.beat._id,
          },
        })

        this.$router.push('/')
      } catch (error) {
        console.log(error)
      }
    },
    async editBeat() {
      try {
        const { title, bpm, key, genre, _id } = this.beat

        const res = await axios.patch(this.serverUrl + '/beats', {
          _id,
          title,
          bpm,
          key,
          genre,
          audioUrl: this.editedBeat.audio.url,
        })

        if (res.statusText !== 'OK') {
          //error bad response
        }
        Object.assign(this.beat, res.data.beat)
      } catch (error) {
        console.log(error)
      }
    },
  },
  computed: {
    serverUrl() {
      return this.$store.state.serverUrl
    },
    token() {
      return this.$store.state.token
    },
  },
  created() {
    this.getBeat()
  },
}
</script>

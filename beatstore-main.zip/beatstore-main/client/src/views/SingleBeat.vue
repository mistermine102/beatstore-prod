<template>
  <FullpageLoader v-if="isLoading"></FullpageLoader>
  <div v-else>
    <Hero :track="beat" :playable="true"></Hero>
    <InformationCard :attributes="attributes" :track="beat" @deleteTrack="deleteBeat" @likeTrack="likeBeat"></InformationCard>
  </div>
</template>
<script>
import axios from 'axios'
import Hero from '../components/singleTrack/Hero.vue'
import InformationCard from '../components/singleTrack/InformationCard.vue'
import FullpageLoader from '../components/FullpageLoader.vue'

export default {
  components: {
    Hero,
    InformationCard,
    FullpageLoader,
  },
  data() {
    return {
      isLoading: false,
      beat: null,
    }
  },
  methods: {
    async likeBeat() {
      //send request to the server
      const res = await axios.post(this.$store.state.serverUrl + '/beats/' + this.beat._id + '/like')

      if (res.statusText !== 'OK') {
        //an error occured
      }
      //client side (increment by one and turn isLiked to true)
      if (!this.beat.isLiked) {
        this.beat.isLiked = true
        this.beat.totalLikes++
      } else {
        this.beat.isLiked = false
        this.beat.totalLikes--
      }
    },
    async getBeat() {
      try {
        this.isLoading = true
        const { id } = this.$route.params
        const res = await axios.get(this.serverUrl + '/beats/' + id)

        this.beat = res.data.beat
      } catch (error) {
        //error
      } finally {
        this.isLoading = false
      }
    },
    async deleteBeat() {
      try {
        //delete from database
        await axios.delete(this.serverUrl + '/beats', {
          data: {
            beatId: this.beat._id,
          },
        })

        this.$router.push('/')
      } catch (error) {
        console.log(error)
      }
    },
    async editBeat() {
      try {
        const { title, bpm, key, genre, _id } = this.beat

        const res = await axios.patch(this.serverUrl + '/beats', {
          _id,
          title,
          bpm,
          key,
          genre,
          audioUrl: this.editedBeat.audio.url,
        })

        if (res.statusText !== 'OK') {
          //error bad response
        }
        Object.assign(this.beat, res.data.beat)
      } catch (error) {
        console.log(error)
      }
    },
  },
  computed: {
    attributes() {
      if (!this.beat) {
        return {}
      }
      const { bpm, key, genre } = this.beat

      return {
        Bpm: bpm,
        Key: key,
        Genre: genre,
      }
    },
    serverUrl() {
      return this.$store.state.serverUrl
    },
    token() {
      return this.$store.state.token
    },
  },
  created() {
    this.getBeat()
  },
}
</script>

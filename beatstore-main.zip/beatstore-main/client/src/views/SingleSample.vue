<template>
  <div>
    <div class="pb-6 pt-4 bg-grey mb-4 rounded-regular">
      <h2 class="text-center">{{ sample.title }}</h2>
      <img src="" alt="" />
    </div>
    <p class="text-center mb-4">3:17</p>
    <div class="h-[150px] flex justify-center items-center bg-grey mb-8 rounded-regular">
      <PlayPauseBtn :track="sample"></PlayPauseBtn>
    </div>
    <div class="grid grid-cols-3 grid-rows-2 items-center justify-center gap-4">
      <p>
        <span>BPM</span> <span>{{ sample.bpm.toUpperCase() }}</span>
      </p>
      <p>
        <span>KEY</span> <span>{{ sample.key.toUpperCase() }}</span>
      </p>
      <div class="row-span-2 flex flex-col items-center justify-center gap-4">
        <span>{{ sample.price.value }} {{ sample.price.currency }}</span>
        <button class="base-btn">Buy</button>
        <button @click="deleteSample" class="base-btn bg-red-500">Delete</button>
      </div>
      <span class="flex gap-2"> <PlayIcon strokeWidth="1.5" size="24" />{{ sample.totalStreams }}</span>
      <Likes @like="likeSample" :totalLikes="sample.totalLikes" :isLiked="sample.isLiked"></Likes>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
import PlayIcon from '../components/icons/Play.vue'
import Likes from '../components/Likes.vue'
import PlayPauseBtn from '../components/track/PlayPauseBtn.vue'

export default {
  components: {
    PlayIcon,
    Likes,
    PlayPauseBtn,
  },
  data() {
    return {
      sample: null,
    }
  },
  methods: {
    async likeSample() {
      //send request to the server
      const res = await axios.post(this.$store.state.serverUrl + '/samples/' + this.sample._id + '/like')

      if (res.statusText !== 'OK') {
        //an error occured
      }
      //client side (increment by one and turn isLiked to true)
      if (!this.sample.isLiked) {
        this.sample.isLiked = true
        this.sample.totalLikes++
      } else {
        this.sample.isLiked = false
        this.sample.totalLikes--
      }
    },
    async getSample() {
      const { id } = this.$route.params
      const res = await axios.get(this.serverUrl + '/samples/' + id)

      if (res.statusText !== 'OK') {
        //an error occured
      }

      this.sample = res.data.sample
    },
    async deleteSample() {
      try {
        //delete from database
        await axios.delete(this.serverUrl + '/samples', {
          data: {
            sampleId: this.sample._id,
          },
        })

        this.$router.push('/')
      } catch (error) {
        console.log(error)
      }
    },
    async editSample() {
      try {
        const { title, bpm, key, genre, _id } = this.sample

        const res = await axios.patch(this.serverUrl + '/samples', {
          _id,
          title,
          bpm,
          key,
          genre,
          audioUrl: this.editedSample.audio.url,
        })

        if (res.statusText !== 'OK') {
          //error bad response
        }
        Object.assign(this.sample, res.data.sample)
      } catch (error) {
        console.log(error)
      }
    },
    toggleEditModal() {
      this.editModalOpened = !this.editModalOpened
    },
  },
  computed: {
    serverUrl() {
      return this.$store.state.serverUrl
    },
    token() {
      return this.$store.state.token
    },
  },
  created() {
    this.getSample()
  },
}
</script>

<template>
  <FullpageLoader v-if="isLoading"></FullpageLoader>
  <div v-else>
    <Hero :track="sample" :playable="true"></Hero>
    <InformationCard :attributes="attributes" :track="sample" @deleteTrack="deleteSample" @likeTrack="likeSample"></InformationCard>
  </div>
</template>
<script>
import axios from 'axios'
import Hero from '../components/singleTrack/Hero.vue'
import InformationCard from '../components/singleTrack/InformationCard.vue'
import FullpageLoader from '../components/FullpageLoader.vue'

export default {
  components: {
    Hero,
    InformationCard,
    FullpageLoader,
  },
  data() {
    return {
      isLoading: false,
      sample: null,
    }
  },
  methods: {
    async likeSample() {
      //send request to the server
      const res = await axios.post(this.$store.state.serverUrl + '/samples/' + this.sample._id + '/like')

      if (res.statusText !== 'OK') {
        //an error occured
      }
      //client side (increment by one and turn isLiked to true)
      if (!this.sample.isLiked) {
        this.sample.isLiked = true
        this.sample.totalLikes++
      } else {
        this.sample.isLiked = false
        this.sample.totalLikes--
      }
    },
    async getSample() {
      try {
        this.isLoading = true

        const { id } = this.$route.params
        const res = await axios.get(this.serverUrl + '/samples/' + id)

        if (res.statusText !== 'OK') {
          //an error occured
        }

        this.sample = res.data.sample
      } catch (error) {
      } finally {
        this.isLoading = false
      }
    },
    async deleteSample() {
      try {
        //delete from database
        await axios.delete(this.serverUrl + '/samples', {
          data: {
            sampleId: this.sample._id,
          },
        })

        this.$router.push('/')
      } catch (error) {
        console.log(error)
      }
    },
  },
  computed: {
    attributes() {
      if (!this.sample) {
        return {}
      }
      const { bpm, key } = this.sample

      return {
        Bpm: bpm,
        Key: key,
      }
    },
    serverUrl() {
      return this.$store.state.serverUrl
    },
    token() {
      return this.$store.state.token
    },
  },
  created() {
    this.getSample()
  },
}
</script>

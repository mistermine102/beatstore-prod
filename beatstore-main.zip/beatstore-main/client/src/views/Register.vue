<template>
  <div class="flex flex-col items-center justify-center">
    <h2 class="base-heading">Sign up</h2>
    <form class="flex flex-col gap-4 p-4 w-1/2" @submit.prevent="register">
      <div>
        <input v-model="user.email" type="text" placeholder="Email" class="base-input w-full" />
        <p v-if="v$.user.email.$error" class="base-error-msg">{{ v$.user.$errors[0].$message }}</p>
      </div>
      <div>
        <input v-model="user.username" type="text" placeholder="Username" class="base-input w-full" />
        <p v-if="v$.user.username.$error" class="base-error-msg">{{ v$.user.username.$errors[0].$message }}</p>
      </div>
      <div>
        <input v-model="user.password" type="password" placeholder="Password" class="base-input w-full" />
        <p v-if="v$.user.password.$error" class="base-error-msg">{{ v$.user.password.$errors[0].$message }}</p>
      </div>
      <p v-if="error" class="base-error-msg mb-4">{{ error }}</p>
      <BaseButton :isLoading="isLoading">Continue</BaseButton>
    </form>
    <div>
      <p>Already have an account? <router-link class="base-link" to="/login">Log in now</router-link></p>
    </div>
  </div>
</template>

<script>
import BaseButton from '../components/base/BaseButton.vue'
import axios from 'axios'
import { useVuelidate } from '@vuelidate/core'
import { required, email, helpers, minLength } from '@vuelidate/validators'

export default {
  components: {
    BaseButton,
  },
  setup() {
    return {
      v$: useVuelidate(),
    }
  },
  data() {
    return {
      error: null,
      isLoading: false,
      user: {
        email: '',
        username: '',
        password: '',
      },
    }
  },
  validations() {
    return {
      user: {
        email: {
          required: helpers.withMessage('Email is required', required),
          email: helpers.withMessage('Invalid email', email),
        },
        username: {
          required: helpers.withMessage('Password is required', required),
          minLength: helpers.withMessage('Username must be at least 4 characters long', minLength(4)),
        },
        password: {
          required: helpers.withMessage('Password is required', required),
          minLength: helpers.withMessage('Password must be at least 6 characters long', minLength(6)),
        },
      },
    }
  },
  methods: {
    async register() {
      try {
        this.isLoading = true
        this.error = null
        this.v$.$validate()

        if (this.v$.$error) {
          return
        }

        const res = await axios.post(this.$store.state.serverUrl + '/register', this.user)

        if (res.statusText !== 'OK') {
          //an error occured
        }

        const { user, token } = res.data

        this.$store.dispatch('login', {
          user,
          token,
        })
      } catch (error) {
        console.log(error);
        this.error = error.response.data.errors[0].msg
      } finally {
        this.isLoading = false
      }
    },
  },
}
</script>

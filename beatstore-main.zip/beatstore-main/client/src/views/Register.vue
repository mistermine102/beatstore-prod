<template>
  <div class="flex flex-col items-center justify-center">
    <h2 class="base-heading">Sign up</h2>
    <form class="flex flex-col gap-4 p-4 w-1/2" @submit.prevent="register">
      <input v-model="user.email" type="text" placeholder="email" class="base-input" />
      <input v-model="user.username" type="text" placeholder="username" class="base-input" />
      <input v-model="user.password" type="text" placeholder="password" class="base-input" />
      <button class="base-btn">Continue</button>
    </form>
    <div>
      <p>Already have an account? <router-link class="base-link" to="/login">Log in now</router-link></p>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      user: {
        email: '',
        username: '',
        password: '',
      },
    }
  },
  methods: {
    async register() {
      const res = await axios.post(this.$store.state.serverUrl + '/register', this.user)

      if (res.statusText !== 'OK') {
        //an error occured
      }

      const { user, token } = res.data

      this.$store.dispatch('login', {
        user,
        token,
      })
    },
  },
}
</script>

<template>
  <div class="h-full">
    <!-- <canvas id="frontpage-3d-scene" class="w-full h-[400px]"></canvas> -->
    <Hero @selectTrackType="onTrackTypeSelected"></Hero>
    <div class="mb-16">
      <BaseSearchBar></BaseSearchBar>
    </div>
    <BeatFilters></BeatFilters>
    <TracksContainer :tracks="tracks" :heading="heading" :isLoading="isLoading"></TracksContainer>
  </div>
</template>

<script>
import axios from 'axios'
import Hero from '../components/frontpage/Hero.vue'
import BaseSearchBar from '../components/base/BaseSeachBar.vue'
import BeatFilters from '../components/frontpage/BeatFilters.vue'
import TracksContainer from '../components/track/TracksContainer.vue'
import { setup } from '../three'

export default {
  components: {
    Hero,
    BaseSearchBar,
    BeatFilters,
    TracksContainer,
  },
  data() {
    return {
      tracks: [],
      heading: 'Beats',
      selectedTrackType: 'Beat',
      isLoading: false,
      trackTypes: {
        Beat: {
          requestUrl: '/beats',
          responseField: 'beats',
        },
        Sample: {
          requestUrl: '/samples',
          responseField: 'samples',
        },
        Drumkit: {
          requestUrl: '/drumkits',
          responseField: 'drumkits',
        },
      },
    }
  },
  methods: {
    async onTrackTypeSelected(trackType) {
      this.selectedTrackType = trackType

      switch (trackType) {
        case 'Beat':
          this.heading = 'Beats'
          break
        case 'Sample':
          this.heading = 'Samples'
          break
        case 'Drumkit':
          this.heading = 'Drum kits'
          break

        default:
          this.heading = 'All'
          break
      }

      await this.getTracks(this.trackTypes[trackType])
    },
    async getTracks(trackType) {
      try {
        this.isLoading = true

        const res = await axios.get(this.$store.state.serverUrl + trackType.requestUrl)

        //check for errors
        if (res.statusText !== 'OK') {
          //error alert
          return
        }

        this.tracks = res.data[trackType.responseField]
      } catch (error) {
        console.log(error)
      } finally {
        this.isLoading = false
      }
    },
  },
  computed: {
    user() {
      return this.$store.state.user
    },
  },
  watch: {
    async user() {
      await this.getTracks(this.trackTypes[this.selectedTrackType])
    },
  },
  async created() {
    await this.getTracks(this.trackTypes.Beat)
  },
  mounted() {
    // setup()
  },
}
</script>

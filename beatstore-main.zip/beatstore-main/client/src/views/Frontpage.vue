<template>
  <div class="h-full">
    <!-- <canvas id="frontpage-3d-scene" class="w-full h-[400px]"></canvas> -->
    <Hero @selectTrackType="onTrackTypeSelected"></Hero>
    <div class="mb-16">
      <BaseSearchBar></BaseSearchBar>
    </div>
    <BeatFilters></BeatFilters>
    <TracksContainer :tracks="tracks" :heading="heading" :isLoading="isLoading"></TracksContainer>
    <div v-if="areMoreDocs" class="flex justify-center mt-4">
      <button @click="loadMore" class="base-btn">Load more</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import Hero from '../components/frontpage/Hero.vue'
import BaseSearchBar from '../components/base/BaseSeachBar.vue'
import BeatFilters from '../components/frontpage/BeatFilters.vue'
import TracksContainer from '../components/track/TracksContainer.vue'
import { setup } from '../three'

export default {
  components: {
    Hero,
    BaseSearchBar,
    BeatFilters,
    TracksContainer,
  },
  data() {
    return {
      ITEMS_PER_PAGE: 5,
      areMoreDocs: false,
      page: 1,
      tracks: [],
      heading: 'Beats',
      selectedTrackType: 'Beat',
      isLoading: false,
      trackTypes: {
        Beat: {
          requestUrl: '/beats',
          responseField: 'beats',
        },
        Sample: {
          requestUrl: '/samples',
          responseField: 'samples',
        },
        Drumkit: {
          requestUrl: '/drumkits',
          responseField: 'drumkits',
        },
      },
    }
  },
  methods: {
    async loadMore() {
      try {
        this.isLoading = true
        this.page++

        const res = await axios.get(this.$store.state.serverUrl + this.trackTypes[this.selectedTrackType].requestUrl + '/page/' + this.page)

        this.areMoreDocs = res.data.areMoreDocs
        this.tracks = this.tracks.concat(res.data[this.trackTypes[this.selectedTrackType].responseField])
      } catch (error) {
      } finally {
        this.isLoading = false
      }
    },
    async onTrackTypeSelected(trackType) {
      this.selectedTrackType = trackType
      this.page = 1

      switch (trackType) {
        case 'Beat':
          this.heading = 'Beats'
          break
        case 'Sample':
          this.heading = 'Samples'
          break
        case 'Drumkit':
          this.heading = 'Drum kits'
          break

        default:
          this.heading = 'All'
          break
      }

      await this.getTracks(this.trackTypes[trackType])
    },
    async getTracks(trackType) {
      try {
        this.isLoading = true

        const res = await axios.get(this.$store.state.serverUrl + trackType.requestUrl + '/page/' + this.page)

        //check for errors
        if (res.statusText !== 'OK') {
          //error alert
          return
        }

        this.tracks = res.data[trackType.responseField]
        this.areMoreDocs = res.data.areMoreDocs
      } catch (error) {
        console.log(error)
      } finally {
        this.isLoading = false
      }
    },
  },
  computed: {
    user() {
      return this.$store.state.user
    },
  },
  watch: {
    async user() {
      await this.getTracks(this.trackTypes[this.selectedTrackType])
    },
  },
  async created() {
    await this.getTracks(this.trackTypes.Beat)
  },
  mounted() {
    // setup()
  },
}
</script>

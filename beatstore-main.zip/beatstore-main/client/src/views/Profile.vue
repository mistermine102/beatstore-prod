<template>
  <div>
    <Hero></Hero>
    <RecentUpload :isLoading="isLoading" :track="profile.recentUpload"></RecentUpload>
    <div class="mt-8">
      <TracksContainer :isLoading="isLoading" :tracks="profile.uploads" heading="Uploads"></TracksContainer>
    </div>
  </div>
</template>
<script>
import Hero from '../components/profile/Hero.vue'
import RecentUpload from '../components/profile/RecentUpload.vue'
import TracksContainer from '../components/track/TracksContainer.vue'
import axios from 'axios'

export default {
  components: {
    Hero,
    RecentUpload,
    TracksContainer,
  },
  data() {
    return {
      isLoading: false,
      profile: {},
    }
  },
  methods: {
    async getProfile() {
      try {
        this.isLoading = true
        const { id } = this.$route.params

        const res = await axios.get(this.serverUrl + '/profile/' + id)
        this.profile = res.data.user
      } catch (error) {
        this.$store.dispatch('showAlert', {
          type: 'error',
          title: 'Something went wrong',
        })
      } finally {
        this.isLoading = false
      }
    },
  },
  computed: {
    serverUrl() {
      return this.$store.state.serverUrl
    },
  },
  created() {
    this.getProfile()
  },
}
</script>

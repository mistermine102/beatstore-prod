<template>
  <div class="min-h-[100vh] bg-background flex flex-col justify-between">
    <Alert></Alert>
    <TheNavbar></TheNavbar>
    <main class="flex flex-col flex-1 px-[10px] sm:px-[25px] lg:px-[100px] xl:px-[150px] 2xl:px-[300px] mt-[100px]">
      <RouterView />
    </main>
    <TheFooter></TheFooter>
    <TheCurrentlyPlaying v-if="this.$store.state.currentlyPlaying?.track"></TheCurrentlyPlaying>
  </div>
</template>

<script>
import axios from 'axios'
import TheNavbar from './components/layout/TheNavbar.vue'
import TheFooter from './components/layout/TheFooter.vue'
import TheCurrentlyPlaying from './components/TheCurrentlyPlaying.vue'
import Alert from './components/Alert.vue'

export default {
  components: {
    TheNavbar,
    TheFooter,
    TheCurrentlyPlaying,
    Alert
  },
  methods: {
    async getUser() {
      const token = localStorage.getItem('token')

      if (!token) {
        return
      }

      this.$store.commit('setToken', token)

      const res = await axios.get(this.$store.state.serverUrl + '/auth/' + token)

      if (res.statusText !== 'OK') {
        //an error
      }

      const { user } = res.data

      this.$store.commit('setUser', user)
    },
  },
  created() {
    this.getUser()
  },
}
</script>

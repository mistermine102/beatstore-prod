<template>
  <div class="py-4 duration-bar-container" @mousedown.prevent="handleScrubEnter" ref="durationBar">
    <div class="duration-bar min-w-[100px]">
      <div class="thumb" @mousedown.prevent="handleScrubEnter" :style="thumbStyles"></div>
      <div class="progress" :style="progressStyles"></div>
    </div>
  </div>
</template>
<script>
export default {
  props: ['percentage'],
  data() {
    return {}
  },
  computed: {
    thumbStyles() {
      return {
        left: this.percentage + '%',
      }
    },
    progressStyles() {
      return {
        right: 100 - this.percentage + '%',
      }
    },
  },
  methods: {
    handleMouseMove(e) {
      let percentage = 0

      const leftBound = this.$refs.durationBar.offsetLeft
      const rightBound = this.$refs.durationBar.offsetLeft + this.$refs.durationBar.offsetWidth
      const durationBarWidth = this.$refs.durationBar.offsetWidth

      if (e.clientX >= leftBound && e.clientX <= rightBound) {
        percentage = ((e.clientX - leftBound) / durationBarWidth) * 100
      } else if (e.clientX < leftBound) {
        percentage = 0
      } else {
        percentage = 100
      }

      this.$emit('percentageChange', percentage)
    },
    handleScrubEnter() {
      document.addEventListener('mousemove', this.handleMouseMove)
      document.addEventListener('mouseup', this.handleScrubLeave)
    },
    handleScrubLeave() {
      document.removeEventListener('mousemove', this.handleMouseMove)
      document.removeEventListener('mouseup', this.handleScrubLeave)
    },
  },
}
</script>
<style scoped>
.duration-bar-container:hover .thumb {
  opacity: 100;
}

.duration-bar {
  position: relative;
  background-color: white;
  height: 6px;
  width: 100%;
  z-index: 0;
  border-radius: 4rem;
}
.thumb {
  background-color: var(--textPrimary);
  z-index: 2;
  width: 12px;
  height: 12px;
  position: absolute;
  transform: translateY(-3px) translateX(-4px);
  border-radius: 100%;
  opacity: 0;
  transition: opacity 100ms ease-in-out;
}

.progress {
  background-color: var(--primary);
  position: absolute;
  inset: 0;
  z-index: 1;
  border-radius: 4rem 0 0 4rem;
  pointer-events: none;
}
</style>

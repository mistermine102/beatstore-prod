<template>
  <BaseModalEmpty @close="$emit('close')">
    <slot></slot>
    <div class="text-white flex justify-center gap-4 pb-2">
      <button @click="$emit('accept')" class="base-btn" :class="acceptBtnClasses">{{ acceptBtnCaption }}</button>
      <button @click="$emit('close')" class="base-btn-alt" :class="closeBtnClasses">{{ closeBtnCaption }}</button>
    </div>
  </BaseModalEmpty>
</template>

<script>
import BaseModalEmpty from './BaseModalEmpty.vue'

export default {
  props: {
    closeBtnClasses: {
      type: Array,
      default: [],
    },
    acceptBtnClasses: {
      type: Array,
      default: [],
    },
    acceptBtnCaption: {
      type: String,
      default: 'Accept',
    },
    closeBtnCaption: {
      type: String,
      default: 'Close',
    },
  },
  components: {
    BaseModalEmpty,
  },
}
</script>

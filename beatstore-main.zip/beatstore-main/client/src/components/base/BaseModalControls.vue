<template>
  <BaseModalEmpty>
    <slot></slot>
    <div>
        <button>Accept</button>
        <button>Close</button>
    </div>
  </BaseModalEmpty>
</template>

<script>
import BaseModalEmpty from './BaseModalEmpty.vue'

export default {
  components: {
    BaseModalEmpty,
  },
}
</script>

<template>
  <span :class="[`bg-${color}-300 text-${color}-700`, 'px-4 rounded-full']">
    <slot></slot>
  </span>
</template>
<script>
export default {
  props: {
    color: {
      type: String,
      default: 'blue',
    },
  },
}
</script>

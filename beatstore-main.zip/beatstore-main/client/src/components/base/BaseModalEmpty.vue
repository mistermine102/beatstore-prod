<template>
  <div @click="close" class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="fixed inset-0 bg-black bg-opacity-75 transition-opacity" aria-hidden="true"></div>
    <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
      <div class="flex min-h-full items-end justify-center text-center sm:items-center sm:p-0">
        <div
          @click.stop=""
          class="relative transform overflow-hidden rounded-lg bg-background text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg p-2"
        >
          <div class="w-full flex justify-end">
            <button @click="close">
              <XSmallIcon size="32" />
            </button>
          </div>
          <div class="bg-background">
            <slot></slot>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import XSmallIcon from '../icons/XSmall.vue'

export default {
  components: {
    XSmallIcon,
  },
  methods: {
    close() {
      this.$emit('close')
    },
  },
}
</script>

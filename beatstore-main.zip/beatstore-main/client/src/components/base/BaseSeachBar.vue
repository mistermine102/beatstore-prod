<template>
  <form class="flex flex-col items-center gap-4">
    <input class="w-full base-input bg-white focus:outline-black px-2 py-2 text-grey" placeholder="What are you looking for?" type="text" />
    <button class="base-btn-alt w-fit">Search</button>
  </form>
</template>

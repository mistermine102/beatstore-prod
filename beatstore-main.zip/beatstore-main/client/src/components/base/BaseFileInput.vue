<template>
  <input @change="onFileSelected" type="file" class="hidden" />
</template>
<script>
export default {
  emits: ['fileSelected'],
  data() {
    return {
      file: null,
    }
  },
  methods: {
    onFileSelected(event) {
      this.file = event.target.files[0]
      this.$emit('fileSelected', {
        file: this.file,
        formattedFileSize: this.fileSize,
      })
    },
  },
  computed: {
    fileSize() {
      const fileSize = this.file.size

      if (fileSize.length < 7) return `${Math.round(+fileSize / 1024).toFixed(2)}kb`
      return `${(Math.round(+fileSize / 1024) / 1000).toFixed(2)}MB`
    },
  },
}
</script>

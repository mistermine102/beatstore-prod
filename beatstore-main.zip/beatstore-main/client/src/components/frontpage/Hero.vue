<template>
  <div class="w-full h-[300px] relative mb-8">
    <div class="absolute w-full h-full flex justify-center items-center">
      <!-- <div class="bg-primary h-[20%] w-[90%] blur-[200px]"></div> -->
    </div>
    <div class="w-full h-full absolute bg-darkGrey rounded-regular shadow-lg p-8">
      <div class="w-full h-full flex flex-col gap-8 justify-between">
        <h1 class="base-heading text-left">I'm trying to find some ...</h1>
        <div class="grid grid-cols-3 w-full h-1/2 gap-8">
          <button
            @click="selectTrackType('Beat')"
            class="relative w-full h-full flex justify-center items-center text-white base-btn bg-gradient-to-br from-violet-800 to-violet-600 card-button"
          >
            <!-- <img src="/images/beats.svg" alt="Beats" class="absolute w-12" /> -->
            <span class="text-2xl z-[2]">Beats</span>
          </button>
          <button
            @click="selectTrackType('Sample')"
            class="relative w-full h-full flex justify-center items-center text-white base-btn bg-gradient-to-br from-violet-800 to-violet-600 card-button shadow-lg"
          >
            <span class="text-2xl z-[2]">Samples</span>
            <!-- <img src="/images/samples.svg" alt="Samples" class="absolute w-12" /> -->
          </button>
          <button
            @click="selectTrackType('Drumkit')"
            class="relative w-full h-full flex justify-center items-center text-white base-btn bg-gradient-to-br from-violet-800 to-violet-600 card-button shadow-lg"
          >
            <span class="text-2xl z-[2]">Drum Kits</span>
            <!-- <img src="/images/drums.svg" alt="Drumkits" class="absolute w-12" /> -->
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  emits: ['selectTrackType'],
  methods: {
    selectTrackType(trackType) {
      this.$emit('selectTrackType', trackType)
    },
  },
}
</script>

<style scoped>
.card-button {
  box-shadow: 0px 0px 1000px -30px var(--primary);
  /* backdrop-filter: blur(200px); */
}
</style>

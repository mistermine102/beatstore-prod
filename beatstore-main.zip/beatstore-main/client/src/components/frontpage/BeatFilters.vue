<template>
    <div class="bg-grey p-8 mb-8 flex w-full justify-around rounded-regular shadow-lg">
        <span>Popularity</span>
        <span>BPM</span>
        <span>Key</span>
        <span>Genre</span>
        <span>Price</span>
        <span>Duration</span>
    </div>
</template>
<script>


</script>
<template>
  <div class="flex flex-col">
    <h2 class="base-heading">Upload a beat</h2>
    <form class="flex flex-col gap-4 w-full" @submit.prevent="">
      <UploadFileContainer id="beat-upload" maxFileSize="25MB" accept="audio/*" @fileSelected="onFileSelected">
        <template #icon>
          <ShareBoxIcon size="128" />
        </template>
      </UploadFileContainer>
      <p v-if="error" class="base-error-msg">{{ error }}</p>
      <div>
        <h3 class="mb-4">Basic information</h3>
        <div class="grid grid-cols-3 gap-4">
          <div>
            <input v-model="newBeat.title" id="title" class="base-input w-full" type="text" placeholder="Title" />
            <p v-if="v$.newBeat.title.$error" class="base-error-msg">{{ v$.newBeat.title.$errors[0].$message }}</p>
          </div>
          <div>
            <input v-model="newBeat.bpm" id="bpm" class="base-input w-full" type="text" placeholder="Bpm" />
            <p v-if="v$.newBeat.bpm.$error" class="base-error-msg">{{ v$.newBeat.bpm.$errors[0].$message }}</p>
          </div>
          <div>
            <input v-model="newBeat.key" id="key" class="base-input w-full" type="text" placeholder="Key" />
            <p v-if="v$.newBeat.key.$error" class="base-error-msg">{{ v$.newBeat.key.$errors[0].$message }}</p>
          </div>
          <div>
            <input v-model="newBeat.genre" id="genre" class="base-input w-full" type="text" placeholder="Genre" />
            <p v-if="v$.newBeat.genre.$error" class="base-error-msg">{{ v$.newBeat.genre.$errors[0].$message }}</p>
          </div>
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Price</h3>
        <div class="grid grid-cols-3 gap-4">
          <div>
            <input v-model="newBeat.price" id="price" class="base-input w-full" type="text" placeholder="Price" />
            <p v-if="v$.newBeat.price.$error" class="base-error-msg">{{ v$.newBeat.price.$errors[0].$message }}</p>
          </div>
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Image</h3>
        <UploadFileContainer id="image-upload" maxFileSize="25MB" accept="image/*" @fileSelected="onImageSelected" class="w-1/4">
          <template #icon>
            <ImageIcon size="96" />
          </template>
        </UploadFileContainer>
      </div>
      <div class="flex justify-center">
        <div class="w-1/4">
          <BaseButton @click="uploadBeat" :isLoading="isLoading">Upload</BaseButton>
        </div>
      </div>
    </form>
  </div>
</template>
<script>
import axios from 'axios'
import UploadFileContainer from '../UploadFileContainer.vue'
import ShareBoxIcon from '../../icons/ShareBox.vue'
import ImageIcon from '../../icons/Image.vue'
import BaseButton from '../../base/BaseButton.vue'
import { useVuelidate } from '@vuelidate/core'
import { required, helpers } from '@vuelidate/validators'

export default {
  components: {
    UploadFileContainer,
    ShareBoxIcon,
    ImageIcon,
    BaseButton,
  },
  setup() {
    return {
      v$: useVuelidate(),
    }
  },
  data() {
    return {
      error: null,
      isLoading: false,
      newBeat: {
        title: '',
        bpm: '',
        key: '',
        genre: '',
        price: null,
        audio: null,
        image: null,
      },
    }
  },
  validations() {
    return {
      newBeat: {
        title: {
          required: helpers.withMessage('Title is required', required),
        },
        bpm: {
          required: helpers.withMessage('Bpm is required', required),
        },
        key: {
          required: helpers.withMessage('Key is required', required),
        },
        genre: {
          required: helpers.withMessage('Genre is required', required),
        },
        price: {
          required: helpers.withMessage('Price is required', required),
        },
      },
    }
  },
  methods: {
    onImageSelected(file) {
      this.newBeat.image = file
    },
    onFileSelected(file) {
      this.error = null
      this.newBeat.audio = file
    },
    async uploadBeat() {
      try {
        this.isLoading = true
        this.error = null
        this.v$.$validate()

        if (!this.newBeat.audio) {
          this.error = 'Audio file is missing'
          return
        }

        if (this.v$.$error) {
          return
        }

        //uploads beat to database
        const res = await axios.postForm(this.$store.state.serverUrl + '/beats', {
          ...this.newBeat,
          image: null,
        })

        if (res.statusText !== 'OK') {
          return
        }

        const id = res.data.newBeat._id

        await axios.postForm(this.$store.state.serverUrl + '/beats/' + id + '/image', {
          image: this.newBeat.image,
        })

        this.$router.push('/beat/' + id)

        this.$store.dispatch('showAlert', {
          type: 'success',
          title: 'Beat uploaded succesfully',
        })
      } catch (error) {
        console.log(error)
      } finally {
        this.isLoading = false
      }
    },
  },
}
</script>

<template>
  <div class="flex flex-col">
    <h2 class="base-heading">Upload a beat</h2>
    <form class="flex flex-col gap-4 w-full" @submit.prevent="">
      <UploadFileContainer id="beat-upload" maxFileSize="25MB" accept="audio/*" @fileSelected="onFileSelected">
        <template #icon>
          <ShareBoxIcon size="128" />
        </template>
      </UploadFileContainer>
      <div>
        <h3 class="mb-4">Basic information</h3>
        <div class="grid grid-cols-3 gap-4">
          <input v-model="newBeat.title" id="title" class="base-input" type="text" placeholder="Title" />
          <input v-model="newBeat.bpm" id="bpm" class="base-input" type="text" placeholder="Bpm" />
          <input v-model="newBeat.key" id="key" class="base-input" type="text" placeholder="Key" />
          <input v-model="newBeat.genre" id="genre" class="base-input" type="text" placeholder="Genre" />
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Price</h3>
        <div class="grid grid-cols-3 gap-4">
          <input v-model.number="newBeat.price" type="text" class="base-input" placeholder="price" />
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Image</h3>
        <UploadFileContainer id="image-upload" maxFileSize="25MB" accept="image/*" @fileSelected="onImageSelected" class="w-1/4">
          <template #icon>
            <ImageIcon size="96" />
          </template>
        </UploadFileContainer>
      </div>
      <div class="flex justify-center">
        <button @click="uploadBeat" class="base-btn w-1/4">Upload</button>
      </div>
    </form>
  </div>
</template>
<script>
import axios from 'axios'
import UploadFileContainer from '../UploadFileContainer.vue'
import ShareBoxIcon from '../../icons/ShareBox.vue'
import ImageIcon from '../../icons/Image.vue'

export default {
  components: {
    UploadFileContainer,
    ShareBoxIcon,
    ImageIcon,
  },
  data() {
    return {
      newBeat: {
        title: '',
        bpm: '',
        key: '',
        genre: '',
        price: null,
        audio: null,
        image: null,
      },
    }
  },
  methods: {
    onImageSelected(file) {
      this.newBeat.image = file
    },
    onFileSelected(file) {
      this.newBeat.audio = file
    },
    async uploadBeat() {
      try {
        //uploads beat to database
        const res = await axios.postForm(this.$store.state.serverUrl + '/beats', {
          ...this.newBeat,
          image: null,
        })

        if (res.statusText !== 'OK') {
          return
        }

        const id = res.data.newBeat._id

        await axios.postForm(this.$store.state.serverUrl + '/beats/' + id + '/image', {
          image: this.newBeat.image,
        })
      } catch (error) {
        console.log(error)
      }
    },
  },
}
</script>

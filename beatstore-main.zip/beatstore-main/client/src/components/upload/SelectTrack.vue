<template>
  <div>
    <h1 class="base-heading text-center mb-16">What do you want to upload</h1>
    <div class="flex justify-around">
      <button @click="selectTrack('Beat')" class="base-btn">Beat</button>
      <button @click="selectTrack('Sample')" class="base-btn">Sample</button>
      <button @click="selectTrack('Drumkit')" class="base-btn">Drum Kit</button>
    </div>
  </div>
</template>
<script>
export default {
  emits: ['selectTrack'],
  methods: {
    selectTrack(trackType) {
      this.$emit('selectTrack', trackType)
    },
  },
}
</script>

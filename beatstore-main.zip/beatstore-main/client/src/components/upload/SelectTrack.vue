<template>
  <div>
    <h1 class="base-heading mb-16">What do you want to upload</h1>
    <div class="grid grid-cols-3 gap-8 text-2xl h-[100px]">
      <button
        @click="selectTrack('Beat')"
        class="w-full h-full flex justify-center items-center rounded-regular text-white border border-textLightGrey hover:bg-primary hover:border-none"
      >
        Beat
      </button>
      <button
        @click="selectTrack('Sample')"
        class="w-full h-full flex justify-center items-center rounded-regular text-white border border-textLightGrey hover:bg-primary hover:border-none"
      >
        Sample
      </button>
      <button
        @click="selectTrack('Drumkit')"
        class="w-full h-full flex justify-center items-center rounded-regular text-white border border-textLightGrey hover:bg-primary hover:border-none"
      >
        Drum Kit
      </button>
    </div>
    <div class="flex justify-center ">
      <img src="/images/piano.png" alt="" />
    </div>
  </div>
</template>
<script>
export default {
  emits: ['selectTrack'],
  methods: {
    selectTrack(trackType) {
      this.$emit('selectTrack', trackType)
    },
  },
}
</script>

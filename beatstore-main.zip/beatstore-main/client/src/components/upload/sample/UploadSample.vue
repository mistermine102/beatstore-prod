<template>
  <div class="flex flex-col">
    <h2 class="base-heading">Upload a sample</h2>
    <form class="flex flex-col gap-4 w-full" @submit.prevent="">
      <UploadFileContainer id="sample-upload" accept="audio/*" maxFileSize="25MB" @fileSelected="onFileSelected">
        <template #icon>
          <ShareBoxIcon size="128" />
        </template>
      </UploadFileContainer>
      <div>
        <h3 class="mb-4">Sample information</h3>
        <div class="grid grid-cols-3 gap-4">
          <input v-model="newSample.title" id="title" class="base-input" type="text" placeholder="Title" />
          <input v-model="newSample.bpm" id="bpm" class="base-input" type="text" placeholder="Bpm" />
          <input v-model="newSample.key" id="key" class="base-input" type="text" placeholder="Key" />
          <input v-model="newSample.genre" id="genre" class="base-input" type="text" placeholder="Genre" />
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Sample price</h3>
        <div class="grid grid-cols-3 gap-4">
          <input v-model="newSample.price" type="text" class="base-input" placeholder="price" />
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Image</h3>
        <UploadFileContainer id="image-upload" maxFileSize="25MB" accept="image/*" @fileSelected="onImageSelected" class="w-1/4">
          <template #icon>
            <ImageIcon size="96" />
          </template>
        </UploadFileContainer>
      </div>
      <div class="flex justify-center">
        <button @click="uploadSample" class="base-btn w-1/4">Upload</button>
      </div>
    </form>
  </div>
</template>
<script>
import axios from 'axios'
import UploadFileContainer from '../UploadFileContainer.vue'
import ShareBoxIcon from '../../icons/ShareBox.vue'
import ImageIcon from '../../icons/Image.vue'

export default {
  components: {
    UploadFileContainer,
    ShareBoxIcon,
    ImageIcon,
  },
  data() {
    return {
      newSample: {
        title: '',
        bpm: '',
        key: '',
        genre: '',
        price: null,
        audio: null,
        image: null,
      },
    }
  },
  methods: {
    onImageSelected(file) {
      this.newSample.image = file
    },
    onFileSelected(file) {
      this.newSample.audio = file
    },
    async uploadSample() {
      try {
        //uploads sample to database
        const res = await axios.postForm(this.$store.state.serverUrl + '/samples', {
          ...this.newSample,
          image: null,
        })

        if (res.statusText !== 'OK') {
          //an error occured
          return
        }

        const id = res.data.newSample._id

        await axios.postForm(this.$store.state.serverUrl + '/samples/' + id + '/image', {
          image: this.newSample.image,
        })
      } catch (error) {
        console.log(error)
      }
    },
  },
}
</script>

<template>
  <div class="flex flex-col">
    <h2 class="base-heading">Upload a sample</h2>
    <form class="flex flex-col gap-4 w-full" @submit.prevent="">
      <UploadFileContainer id="sample-upload" accept="audio/*" maxFileSize="25MB" @fileSelected="onFileSelected">
        <template #icon>
          <ShareBoxIcon size="128" />
        </template>
      </UploadFileContainer>
      <p v-if="error" class="base-error-msg">{{ error }}</p>
      <div>
        <h3 class="mb-4">Sample information</h3>
        <div class="grid grid-cols-3 gap-4">
          <div>
            <input v-model="newSample.title" id="title" class="base-input w-full" type="text" placeholder="Title" />
            <p v-if="v$.newSample.title.$error" class="base-error-msg">{{ v$.newSample.title.$errors[0].$message }}</p>
          </div>
          <div>
            <input v-model="newSample.bpm" id="bpm" class="base-input w-full" type="text" placeholder="Bpm" />
            <p v-if="v$.newSample.bpm.$error" class="base-error-msg">{{ v$.newSample.bpm.$errors[0].$message }}</p>
          </div>
          <div>
            <input v-model="newSample.key" id="key" class="base-input w-full" type="text" placeholder="Key" />
            <p v-if="v$.newSample.key.$error" class="base-error-msg">{{ v$.newSample.key.$errors[0].$message }}</p>
          </div>
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Sample price</h3>
        <div class="grid grid-cols-3 gap-4">
          <div>
            <input v-model="newSample.price" type="text" class="base-input w-full" placeholder="price" />
            <p v-if="v$.newSample.price.$error" class="base-error-msg">{{ v$.newSample.price.$errors[0].$message }}</p>
          </div>
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Image</h3>
        <UploadFileContainer id="image-upload" maxFileSize="25MB" accept="image/*" @fileSelected="onImageSelected" class="w-1/4">
          <template #icon>
            <ImageIcon size="96" />
          </template>
        </UploadFileContainer>
      </div>
      <div class="flex justify-center">
        <div class="w-1/4">
          <BaseButton @click="uploadSample" :isLoading="isLoading">Upload</BaseButton>
        </div>
      </div>
    </form>
  </div>
</template>
<script>
import axios from 'axios'
import UploadFileContainer from '../UploadFileContainer.vue'
import ShareBoxIcon from '../../icons/ShareBox.vue'
import ImageIcon from '../../icons/Image.vue'
import BaseButton from '../../base/BaseButton.vue'
import { useVuelidate } from '@vuelidate/core'
import { required, helpers } from '@vuelidate/validators'

export default {
  components: {
    UploadFileContainer,
    ShareBoxIcon,
    ImageIcon,
    BaseButton,
  },
  setup() {
    return {
      v$: useVuelidate(),
    }
  },
  data() {
    return {
      isLoading: false,
      error: null,
      newSample: {
        title: '',
        bpm: '',
        key: '',
        genre: '',
        price: null,
        audio: null,
        image: null,
      },
    }
  },
  validations() {
    return {
      newSample: {
        title: {
          required: helpers.withMessage('Title is required', required),
        },
        bpm: {
          required: helpers.withMessage('Bpm is required', required),
        },
        key: {
          required: helpers.withMessage('Key is required', required),
        },
        price: {
          required: helpers.withMessage('Price is required', required),
        },
      },
    }
  },
  methods: {
    onImageSelected(file) {
      this.newSample.image = file
    },
    onFileSelected(file) {
      this.newSample.audio = file
      this.error = null
    },
    async uploadSample() {
      try {
        this.isLoading = true
        this.error = null
        this.v$.$validate()

        if (!this.newSample.audio) {
          this.error = 'Audio file is missing'
          return
        }

        if (this.v$.$error) {
          return
        }
        //uploads sample to database
        const res = await axios.postForm(this.$store.state.serverUrl + '/samples', {
          ...this.newSample,
          image: null,
        })

        if (res.statusText !== 'OK') {
          //an error occured
          return
        }

        const id = res.data.newSample._id

        await axios.postForm(this.$store.state.serverUrl + '/samples/' + id + '/image', {
          image: this.newSample.image,
        })
      } catch (error) {
        console.log(error)
      } finally {
        this.isLoading = false
      }
    },
  },
}
</script>

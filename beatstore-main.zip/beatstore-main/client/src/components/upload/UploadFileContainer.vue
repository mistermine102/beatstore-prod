<template>
  <div class="border-2 border-dashed border-primary rounded-regular">
    <label :for="id" class="cursor-pointer w-full h-full p-8">
      <div v-if="!file" class="flex flex-col items-center justify-center">
        <slot name="icon"></slot>
        <p class="mt-4">Drag and drop or <span class="base-link">select a file</span></p>
      </div>
      <div v-else class="flex flex-col items-center justify-center gap-4">
        <span>{{ file.name }}</span>
        <span class="text-textPrimary">{{ formattedFileSize }}</span>
        <span class="text-gray-300 text-sm">Max file size is {{ maxFileSize }}</span>
      </div>
    </label>
    <BaseFileInput @fileSelected="onFileSelected" :id="id" :accept="accept"/>
  </div>
</template>
<script>
import BaseFileInput from '../base/BaseFileInput.vue'

export default {
  props: ['maxFileSize', 'id', 'accept'],
  emits: ['fileSelected'],
  components: {
    BaseFileInput,
  },
  data() {
    return {
      file: null,
      formattedFileSize: null,
    }
  },
  methods: {
    onFileSelected(payload) {
      this.file = payload.file
      this.formattedFileSize = payload.formattedFileSize

      this.$emit('fileSelected', payload.file)
    },
  },
}
</script>

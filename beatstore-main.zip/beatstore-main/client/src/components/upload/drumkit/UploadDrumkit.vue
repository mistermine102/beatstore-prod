<template>
  <div class="flex flex-col">
    <h2 class="base-heading mb-16">Upload a drum kit</h2>
    <form class="flex flex-col gap-4 w-full" @submit.prevent="">
      <div>
        <h3 class="text-lg mb-2">Basic information</h3>
        <div class="grid grid-cols-3 gap-4">
          <input v-model.trim="newDrumkit.title" id="title" class="base-input" type="text" placeholder="Title" />
        </div>
      </div>
      <div>
        <h3 class="text-lg mb-2">Drums</h3>
        <DrumsConstructor
          :directories="newDrumkit.directories"
          @fileSelected="onFileSelected"
          @addDirectory="addDirectory"
          @addDrum="addDrum"
          @directoryTitleChanged="onDirectoryTitleChange"
          @removeDirectory="removeDirectory"
          @removeDrum="removeDrum"
          @changeDrumTitle="changeDrumTitle"
        ></DrumsConstructor>
      </div>
      <div class="mb-8">
        <h3 class="text-lg mb-2">Price</h3>
        <div class="grid grid-cols-3 gap-4">
          <input v-model.number="newDrumkit.price" type="text" class="base-input" placeholder="price" />
        </div>
      </div>
      <div class="mb-8">
        <h3 class="mb-4">Image</h3>
        <UploadFileContainer id="image-upload" maxFileSize="25MB" accept="image/*" @fileSelected="onImageSelected" class="w-1/4">
          <template #icon>
            <ImageIcon size="96" />
          </template>
        </UploadFileContainer>
      </div>
      <div class="flex justify-center">
        <button @click="uploadDrumkit" class="base-btn w-1/4">Upload</button>
      </div>
    </form>
  </div>
</template>

<script>
import DrumsConstructor from './DrumsConstructor.vue'
import UploadFileContainer from '../UploadFileContainer.vue'
import ImageIcon from '../../icons/Image.vue'
import axios from 'axios'

export default {
  components: {
    DrumsConstructor,
    UploadFileContainer,
    ImageIcon,
  },
  data() {
    return {
      newDrumkit: {
        title: '',
        price: null,
        image: null,
        directories: [
          {
            title: 'Kicks',
            drums: [
              {
                title: 'Rack kick',
                type: 'kick',
                audio: null,
                formattedFileSize: null,
              },
              {
                title: 'Ghost kick',
                type: 'kick',
                audio: null,
                formattedFileSize: null,
              },
            ],
          },
          {
            title: 'Snares',
            drums: [
              {
                title: 'Rack kick',
                type: 'kick',
                audio: null,
                formattedFileSize: null,
              },
              {
                title: 'Ghost kick',
                type: 'kick',
                audio: null,
                formattedFileSize: null,
              },
            ],
          },
        ],
      },
    }
  },
  methods: {
    onImageSelected(file) {
      this.newDrumkit.image = file
    },
    renameFile(originalFile, newName) {
      return new File([originalFile], newName, {
        type: originalFile.type,
        lastModified: originalFile.lastModified,
      })
    },
    async uploadDrumkit() {
      //extract all audio files into a single array
      let files = []

      for (const directory of this.newDrumkit.directories) {
        for (const drum of directory.drums) {
          if (drum.audio) {
            //name them accoring to their directory name and drum name
            const file = this.renameFile(drum.audio, `dir-${directory.title}-drum-${drum.title}`)
            delete drum.audio

            files.push(file)
          }
        }
      }

      const res = await axios.postForm(this.$store.state.serverUrl + '/drumkits', {
        drumkit: {
          ...this.newDrumkit,
          image: null,
        },
        audio: files,
      })

      if (res.statusText !== 'OK') {
        return
      }

      const id = res.data.drumkit._id

      console.log(this.newDrumkit.image);

      await axios.postForm(this.$store.state.serverUrl + '/drumkits/' + id + '/image', {
        image: this.newDrumkit.image,
      })
    },
    changeDrumTitle({ newTitle, oldTitle, directoryTitle, target }) {
      const foundDirectory = this.newDrumkit.directories.find(directory => directory.title === directoryTitle)
      // const isTitleAvailable = this.isDrumTitleAvailable(newTitle, foundDirectory)

      // if (!isTitleAvailable) {
      //   target.innerHTML = oldTitle
      //   return
      // }

      const foundDrum = foundDirectory.drums.find(drum => drum.title === oldTitle)
      foundDrum.title = newTitle
    },
    removeDrum(directoryTitle, drumTitle) {
      const foundDirectory = this.newDrumkit.directories.find(directory => directory.title === directoryTitle)
      foundDirectory.drums = foundDirectory.drums.filter(drum => drum.title !== drumTitle)
    },
    removeDirectory(title) {
      this.newDrumkit.directories = this.newDrumkit.directories.filter(directory => directory.title !== title)
    },
    addDrum(directoryTitle) {
      const foundDirectory = this.newDrumkit.directories.find(directory => directory.title === directoryTitle)

      //find available title
      let currentTitle = 'New drum'
      let index = 1

      while (true) {
        const isAvailable = this.isDrumTitleAvailable(currentTitle, foundDirectory)

        if (isAvailable) {
          break
        }
        currentTitle = 'New drum ' + index
        index++
      }

      foundDirectory.drums.push({
        title: currentTitle,
        type: 'Drum',
        audio: null,
        formattedFileSize: null,
      })
    },
    isDirectoryTitleAvailiable(title) {
      for (const directory of this.newDrumkit.directories) {
        if (directory.title === title) {
          return false
        }
      }
      return true
    },
    isDrumTitleAvailable(title, directory) {
      for (const drum of directory.drums) {
        if (drum.title === title) {
          return false
        }
      }
      return true
    },
    addDirectory() {
      //find available title
      let currentTitle = 'New directory'
      let index = 1

      while (true) {
        const isAvailable = this.isDirectoryTitleAvailiable(currentTitle)

        if (isAvailable) {
          break
        }
        currentTitle = 'New directory ' + index
        index++
      }

      //push new directory
      this.newDrumkit.directories.push({
        title: currentTitle,
        drums: [],
      })
    },
    onDirectoryTitleChange({ oldTitle, newTitle, target }) {
      const foundDirectory = this.newDrumkit.directories.find(directory => directory.title === oldTitle)

      // const isTitleAvailable = this.isDirectoryTitleAvailiable(newTitle)

      // if (!isTitleAvailable) {
      //   target.innerHTML = oldTitle
      //   return
      // }

      foundDirectory.title = newTitle
    },
    onFileSelected(payload) {
      const { directoryTitle, drumTitle, file, formattedFileSize } = payload

      const foundDirectory = this.newDrumkit.directories.find(directory => directory.title === directoryTitle)
      const foundDrum = foundDirectory.drums.find(drum => drum.title === drumTitle)

      foundDrum.audio = file
      foundDrum.formattedFileSize = formattedFileSize
    },
  },
}
</script>

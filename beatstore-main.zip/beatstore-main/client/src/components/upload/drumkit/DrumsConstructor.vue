<template>
  <div>
    <ul class="flex flex-col gap-2">
      <li v-for="directory in directories" :key="directory.title">
        <div class="flex items-center justify-between border rounded-sm h-[30px] w-[300px] mb-3 px-2">
          <div class="flex items-center gap-2">
            <FolderIcon size="20" />
            <p @blur="changeDirectoryTitle" :data-title="directory.title" spellcheck="false" contenteditable="true">
              {{ directory.title }}
            </p>
          </div>
          <button @click="removeDirectory(directory.title)" class="ml-4">
            <CircleXIcon size="20" />
          </button>
        </div>
        <ul class="ml-[100px] flex flex-col gap-2">
          <li
            v-for="drum in directory.drums"
            :key="drum.title"
            class="flex gap-4 justify-between px-2 items-center border rounded-sm h-[30px]"
            :class="drum.audio ? 'w-[500px]' : 'w-[300px]'"
          >
            <span contenteditable="true" spellcheck="false" class="bg-gray-300 text-gray-700 font-semibold px-2 rounded-full">Kick</span>
            <p
              @blur="changeDrumTitle($event, directory.title)"
              :data-title="drum.title"
              class="text-center"
              contenteditable="true"
              spellcheck="false"
            >
              {{ drum.title }}
            </p>
            <label :for="`dir-${directory.title}-drum-${drum.title}-upload`" class="cursor-pointer">
              <span v-if="!drum.audio">File</span>
              <span v-else>{{ drum.audio.name.slice(0, 25) }}<span v-if="drum.audio.name.length > 25">...</span></span>
            </label>
            <BaseFileInput
              :id="`dir-${directory.title}-drum-${drum.title}-upload`"
              accept="audio/*"
              @fileSelected="onFileSelected($event, drum.title, directory.title)"
            />
            <button @click="removeDrum(directory.title, drum.title)">
              <CircleXIcon size="20" />
            </button>
          </li>
          <li class="w-[300px] flex justify-left">
            <button @click="addDrum(directory.title)" class="border rounded-sm text-textPrimary text-center w-1/2">+</button>
          </li>
        </ul>
      </li>
      <li class="w-[300px] flex justify-left">
        <button @click="addDirectory" class="border rounded-sm text-textPrimary w-1/2 mb-3 flex justify-center">
          <FolderAddIcon size="24" />
        </button>
      </li>
    </ul>
  </div>
</template>

<script>
import BaseFileInput from '../../base/BaseFileInput.vue'
import FolderIcon from '../../icons/Folder.vue'
import FolderAddIcon from '../../icons/FolderAdd.vue'
import CircleXIcon from '../../icons/CircleX.vue'

export default {
  props: ['directories'],
  emits: ['fileSelected', 'addDirectory', 'addDrum', 'directoryTitleChanged', 'removeDirectory', 'removeDrum', 'changeDrumTitle'],
  components: {
    BaseFileInput,
    FolderIcon,
    FolderAddIcon,
    CircleXIcon,
  },
  methods: {
    removeDrum(directoryTitle, drumTitle) {
      this.$emit('removeDrum', directoryTitle, drumTitle)
    },
    changeDirectoryTitle(e) {
      this.$emit('directoryTitleChanged', {
        oldTitle: e.target.dataset.title,
        newTitle: e.target.textContent,
        target: e.target,
      })
    },
    changeDrumTitle(e, directoryTitle) {
      this.$emit('changeDrumTitle', {
        oldTitle: e.target.dataset.title,
        newTitle: e.target.textContent,
        target: e.target,
        directoryTitle,
      })
    },
    removeDirectory(directoryTitle) {
      this.$emit('removeDirectory', directoryTitle)
    },
    addDirectory() {
      this.$emit('addDirectory')
    },
    addDrum(directoryTitle) {
      this.$emit('addDrum', directoryTitle)
    },
    onFileSelected(payload, drumTitle, directoryTitle) {
      const { file, formattedFileSize } = payload

      this.$emit('fileSelected', {
        file,
        formattedFileSize,
        directoryTitle,
        drumTitle,
      })
    },
  },
}
</script>

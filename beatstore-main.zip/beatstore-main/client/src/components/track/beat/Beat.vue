<template>
  <div class="shadow-lg grid grid-cols-3 rounded-regular items-center py-2 px-4 bg-darkGrey">
    <div class="flex justify-between items-center h-full">
      <img v-if="beat.image" :src="beat.image.url" alt="Beat image" class="rounded-lg h-[100px]" />
      <div class="flex flex-col flex-1 items-center gap-4">
        <PlayPauseBtn :track="beat"></PlayPauseBtn>
      </div>
    </div>
    <div class="flex flex-col justify-center items-center gap-4">
      <h3 class="text-xl">
        <router-link :to="'/beat/' + beat._id">{{ beat.title }}</router-link>
      </h3>
      <span>#3m 17s#</span>
      <div class="flex gap-4 text-textLightGrey">
        <span>Bpm: {{ beat.bpm }}</span>
        <span>Key: {{ beat.key }}</span>
        <span>Genre: {{ beat.genre }}</span>
      </div>
    </div>
    <div class="flex flex-col justify-center items-center gap-4">
      <div class="w-full flex justify-center gap-16">
        <span class="bg-blue-300 text-blue-700 px-4 rounded-full">Beat</span>
        <span class="base-link">Author: {{ beat.author.username }}</span>
      </div>
      <span class="text-lg">{{ beat.price.value }} {{ beat.price.currency }} </span>
      <div class="flex gap-4">
        <div class="flex gap-2">
          <PlayIcon size="24" />
          <span>{{ beat.totalStreams }}</span>
        </div>
        <Likes @like="likeBeat" :totalLikes="beat.totalLikes" :isLiked="beat.isLiked"></Likes>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios'

import PlayIcon from '../../icons/Play.vue'
import PlayPauseBtn from '../PlayPauseBtn.vue'
import Likes from '../../Likes.vue'

export default {
  props: ['beat'],
  components: {
    PlayIcon,
    Likes,
    PlayPauseBtn,
  },
  methods: {
    async likeBeat() {
      try {
        //send request to the server
        await axios.post(this.$store.state.serverUrl + '/beats/' + this.beat._id + '/like')

        //client side (increment by one and turn isLiked to true)
        if (!this.beat.isLiked) {
          this.beat.isLiked = true
          this.beat.totalLikes++
        } else {
          this.beat.isLiked = false
          this.beat.totalLikes--
        }
      } catch (error) {
        if (error.name === 'AxiosError' && error.response.status === 401) {
          this.$store.dispatch('showAlert', {
            type: 'info',
            title: 'You must log in to like a beat.',
          })
        }
      }
    },
  },
  computed: {
    currentlyPlaying() {
      return this.$store.state.currentlyPlaying
    },
    isThatTrackPlaying() {
      if (this.currentlyPlaying.track && this.currentlyPlaying.track._id === this.beat._id && !this.currentlyPlaying.isPaused) {
        return true
      } else {
        return false
      }
    },
  },
}
</script>

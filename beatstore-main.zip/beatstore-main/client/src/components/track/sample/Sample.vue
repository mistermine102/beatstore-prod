<template>
  <div class="shadow-lg grid grid-cols-3 rounded-regular items-center py-2 px-4 bg-darkGrey">
    <div class="flex justify-between items-center h-full">
      <img v-if="sample.image" :src="sample.image.url" alt="Beat image" class="rounded-lg h-[100px]" />
      <div class="flex flex-col flex-1 items-center gap-4">
        <PlayPauseBtn :track="sample"></PlayPauseBtn>
      </div>
    </div>
    <div class="flex flex-col justify-center items-center gap-4">
      <h3 class="text-xl">
        <router-link :to="'/sample/' + sample._id">{{ sample.title }}</router-link>
      </h3>
      <span>#3m 17s#</span>
      <div class="flex gap-4 text-textLightGrey">
        <span>Bpm: {{ sample.bpm }}</span>
        <span>Key: {{ sample.key }}</span>
      </div>
    </div>
    <div class="flex flex-col justify-center items-center gap-4">
      <div class="w-full flex justify-center gap-16">
        <span class="bg-green-300 text-green-700 px-4 rounded-full">Sample</span>
        <span class="base-link">Author: {{ sample.author.username }}</span>
      </div>
      <span>{{ sample.price.value }} {{ sample.price.currency }} </span>
      <div class="flex gap-4">
        <div class="flex gap-2">
          <PlayIcon size="24" />
          <span>{{ sample.totalStreams }}</span>
        </div>
        <Likes @like="likeSample" :totalLikes="sample.totalLikes" :isLiked="sample.isLiked"></Likes>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios'

import PlayIcon from '../../icons/Play.vue'
import PauseIcon from '../../icons/Pause.vue'
import Likes from '../../Likes.vue'
import PlayPauseBtn from '../PlayPauseBtn.vue'

export default {
  props: ['sample'],
  components: {
    PlayIcon,
    PauseIcon,
    Likes,
    PlayPauseBtn,
  },
  methods: {
    async likeSample() {
      try {
        //send request to the server
        await axios.post(this.$store.state.serverUrl + '/samples/' + this.sample._id + '/like')

        //client side (increment by one and turn isLiked to true)
        if (!this.sample.isLiked) {
          this.sample.isLiked = true
          this.sample.totalLikes++
        } else {
          this.sample.isLiked = false
          this.sample.totalLikes--
        }
      } catch (error) {
        if (error.name === 'AxiosError' && error.response.status === 401) {
          this.$store.dispatch('showAlert', {
            type: 'info',
            title: 'You must log in to like a sample.',
          })
        }
      }
    },
  },
}
</script>

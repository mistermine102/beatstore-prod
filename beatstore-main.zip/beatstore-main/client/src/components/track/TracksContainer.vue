<template>
  <div class="h-full">
    <h2 class="base-heading mb-4">{{ heading }}</h2>
    <div v-if="isLoading" class="flex justify-center h-full">
      <div class="loader"></div>
    </div>
    <div v-else>
      <div v-if="!tracks.length" class="flex justify-left">
        <EmptyState></EmptyState>
      </div>
      <div v-else class="grid gap-8">
        <Track v-for="track in tracks" :track="track" :key="track._id"></Track>
      </div>
    </div>
  </div>
</template>

<script>
import EmptyState from '../EmptyState.vue'
import Track from '../trackCard/Track.vue'

export default {
  props: ['tracks', 'heading', 'isLoading'],
  components: {
    EmptyState,
    Track,
  },
}
</script>

<template>
  <div class="h-full">
    <h2 class="base-heading">{{ heading }}</h2>
    <div v-if="isLoading" class="flex justify-center h-full">
      <div class="loader"></div>
    </div>
    <div v-else>
      <div v-if="!tracks.length" class="flex justify-left">
        <EmptyState></EmptyState>
      </div>
      <div v-else class="grid gap-8">
        <div v-for="track in tracks" :key="track._id">
          <Beat v-if="track.trackType === 'Beat'" :beat="track"></Beat>
          <Sample v-if="track.trackType === 'Sample'" :sample="track"></Sample>
          <Drumkit v-if="track.trackType === 'Drumkit'" :drumkit="track"></Drumkit>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Beat from './beat/Beat.vue'
import Sample from './sample/Sample.vue'
import Drumkit from './drumkit/Drumkit.vue'
import EmptyState from '../EmptyState.vue'

export default {
  props: ['tracks', 'heading', 'isLoading'],
  components: {
    Beat,
    Sample,
    Drumkit,
    EmptyState
  },
  computed: {},
}
</script>

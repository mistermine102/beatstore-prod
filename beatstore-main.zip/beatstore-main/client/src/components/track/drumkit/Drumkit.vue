<template>
  <div class="bg-darkGrey shadow-lg grid grid-cols-3 rounded-regular items-center p-2">
    <div class="flex justify-center items-center h-full">
      <img v-if="drumkit.image" :src="drumkit.image.url" alt="Beat image" class="rounded-lg h-[100px]" />
    </div>
    <div class="flex flex-col justify-center items-center gap-4">
      <h3 class="text-xl">
        <router-link :to="'/drumkit/' + drumkit._id">{{ drumkit.title }}</router-link>
      </h3>
    </div>
    <div class="flex flex-col justify-center items-center gap-4">
      <div class="w-full flex justify-center gap-16">
        <span class="bg-orange-300 text-orange-700 px-4 rounded-full">Drumkit</span>
        <span class="base-link">Author: {{ drumkit.author.username }}</span>
      </div>
      <span class="text-lg">{{ drumkit.price.value }} {{ drumkit.price.currency }} </span>
      <div class="flex gap-4">
        <Likes @like="likeDrumkit" :totalLikes="drumkit.totalLikes" :isLiked="drumkit.isLiked"></Likes>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios'

import PlayIcon from '../../icons/Play.vue'
import PlayPauseBtn from '../PlayPauseBtn.vue'
import Likes from '../../Likes.vue'

export default {
  props: ['drumkit'],
  components: {
    PlayIcon,
    Likes,
    PlayPauseBtn,
  },
  methods: {
    async likeDrumkit() {
      try {
        //send request to the server
        await axios.post(this.$store.state.serverUrl + '/drumkits/' + this.drumkit._id + '/like')

        //client side (increment by one and turn isLiked to true)
        if (!this.drumkit.isLiked) {
          this.drumkit.isLiked = true
          this.drumkit.totalLikes++
        } else {
          this.drumkit.isLiked = false
          this.drumkit.totalLikes--
        }
      } catch (error) {
        if (error.name === 'AxiosError' && error.response.status === 401) {
          this.$store.dispatch('showAlert', {
            type: 'info',
            title: 'You must log in to like a drumkit.',
          })
        }
      }
    },
  },
}
</script>

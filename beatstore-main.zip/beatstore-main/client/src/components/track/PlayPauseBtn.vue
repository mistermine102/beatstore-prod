<template>
  <button v-if="!isThatTrackPlaying" @click="playAudio">
    <PlayIcon :fill="true" size="64" />
  </button>
  <button v-else @click="pauseAudio">
    <PauseIcon size="64" />
  </button>
</template>
<script>
import PlayIcon from '../icons/Play.vue'
import PauseIcon from '../icons/Pause.vue'
import axios from 'axios'

export default {
  props: ['track'],
  components: {
    PlayIcon,
    PauseIcon,
  },
  methods: {
    async playAudio() {
      if (!this.currentlyPlaying.track || this.currentlyPlaying.track._id !== this.track._id) {
        let trackUrl = ''

        switch (this.track.trackType) {
          case 'Beat':
            trackUrl = '/beats'
            break
          case 'Sample':
            trackUrl = '/samples'
            break
          default:
            break
        }
        const requestUrl = this.$store.state.serverUrl + trackUrl + '/' + this.track._id + '/stream'
        axios.post(requestUrl)
      }

      this.$store.commit('setCurrentlyPlaying', { track: this.track, isPaused: false })
    },
    pauseAudio() {
      this.$store.commit('setCurrentlyPlaying', { isPaused: true })
    },
  },
  computed: {
    currentlyPlaying() {
      return this.$store.state.currentlyPlaying
    },
    isThatTrackPlaying() {
      if (this.currentlyPlaying.track && this.currentlyPlaying.track._id === this.track._id && !this.currentlyPlaying.isPaused) {
        return true
      } else {
        return false
      }
    },
  },
}
</script>

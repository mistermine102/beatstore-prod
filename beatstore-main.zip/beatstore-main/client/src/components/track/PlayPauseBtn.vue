<template>
  <button v-if="!isThatTrackPlaying" @click="playAudio">
    <PlayIcon :fill="true" size="64" />
  </button>
  <button v-else @click="pauseAudio">
    <PauseIcon size="64" />
  </button>
</template>
<script>
import PlayIcon from '../icons/Play.vue'
import PauseIcon from '../icons/Pause.vue'

export default {
  props: ['track'],
  components: {
    PlayIcon,
    PauseIcon,
  },
  methods: {
    playAudio() {
      this.$store.commit('setCurrentlyPlaying', { track: this.track, isPaused: false })
    },
    pauseAudio() {
      this.$store.commit('setCurrentlyPlaying', { isPaused: true })
    },
  },
  computed: {
    currentlyPlaying() {
      return this.$store.state.currentlyPlaying
    },
    isThatTrackPlaying() {
      if (this.currentlyPlaying.track && this.currentlyPlaying.track._id === this.track._id && !this.currentlyPlaying.isPaused) {
        return true
      } else {
        return false
      }
    },
  },
}
</script>

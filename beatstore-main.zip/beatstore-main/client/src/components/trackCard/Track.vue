<template>
  <div class="shadow-lg grid grid-cols-3 rounded-regular items-center py-2 px-4 bg-darkGrey">
    <div class="flex justify-between items-center h-full">
      <img v-if="track.image" :src="track.image.url" alt="Beat image" class="rounded-lg h-[100px]" />
      <div class="flex flex-col flex-1 items-center gap-4">
        <PlayPauseBtn :track="track"></PlayPauseBtn>
      </div>
    </div>
    <div class="flex flex-col justify-center items-center gap-4">
      <Title :title="track.title" :trackUrl="trackUrl"></Title>
      <Duration :duration="track.audio.duration.formatted"></Duration>
      <Attributes :attributes="attributes"></Attributes>
    </div>
    <div class="flex flex-col justify-center items-center gap-4">
      <div class="w-full flex justify-center gap-16">
        <BaseBadge :color="badge.color">
          <span> {{ badge.caption }}</span>
        </BaseBadge>
        <Author :author="track.author"></Author>
      </div>
      <Price :price="track.price.value" :currency="track.price.currency"></Price>
      <div class="flex gap-4">
        <div class="flex gap-2">
          <PlayIcon size="24" />
          <span>{{ track.totalStreams }}</span>
        </div>
        <Likes @like="likeTrack" :totalLikes="track.totalLikes" :isLiked="track.isLiked"></Likes>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import Attributes from './Attributes.vue'
import Title from './Title.vue'
import Duration from './Duration.vue'
import Price from './Price.vue'
import Author from './Author.vue'
import BaseBadge from '../base/BaseBadge.vue'
import PlayPauseBtn from '../track/PlayPauseBtn.vue'
import Likes from '../Likes.vue'
import PlayIcon from '../icons/Play.vue'

export default {
  props: ['track'],
  components: {
    Attributes,
    Title,
    Duration,
    Price,
    Author,
    BaseBadge,
    PlayPauseBtn,
    Likes,
    PlayIcon,
  },
  methods: {
    async likeTrack() {
      try {
        //send request to the server
        await axios.post(this.$store.state.serverUrl + this.suffixes.endpoint + '/' + this.track._id + '/like')

        //client side (increment by one and turn isLiked to true)
        if (!this.track.isLiked) {
          this.track.isLiked = true
          this.track.totalLikes++
        } else {
          this.track.isLiked = false
          this.track.totalLikes--
        }
      } catch (error) {
        if (error.name === 'AxiosError' && error.response.status === 401) {
          this.$store.dispatch('showAlert', {
            type: 'info',
            title: 'You must be logged in to leave a like',
          })
        } else {
          this.$store.dispatch('showAlert', {
            type: 'error',
            title: 'Something went wrong',
          })
        }
      }
    },
  },
  computed: {
    trackUrl() {
      return this.suffixes.singlePage + '/' + this.track._id
    },
    suffixes() {
      let suffixes = {}

      switch (this.track.trackType) {
        case 'Beat':
          suffixes.singlePage = '/beat'
          suffixes.endpoint = '/beats'
          break
        case 'Sample':
          suffixes.singlePage = '/sample'
          suffixes.endpoint = '/samples'
          break
        case 'Drumkit':
          suffixes.singlePage = '/drumkit'
          suffixes.endpoint = '/drumkits'
          break

        default:
          break
      }

      return suffixes
    },
    attributes() {
      let attributes = {}

      switch (this.track.trackType) {
        case 'Beat':
          {
            const { bpm, key, genre } = this.track

            attributes = {
              Bpm: bpm,
              Key: key,
              Genre: genre,
            }
          }

          break
        case 'Sample':
          {
            const { bpm, key } = this.track

            attributes = {
              Bpm: bpm,
              Key: key,
            }
          }

          break
        case 'Drumkit':
          {
            attributes = {}
          }
          break

        default:
          break
      }

      return attributes
    },
    badge() {
      let badge = {}

      switch (this.track.trackType) {
        case 'Beat':
          badge.color = 'blue'
          badge.caption = 'Beat'
          break
        case 'Sample':
          badge.color = 'green'
          badge.caption = 'Sample'
          break
        case 'Drumkit':
          badge.color = 'orange'
          badge.caption = 'Drumkit'
          break

        default:
          break
      }

      return badge
    },
  },
}
</script>

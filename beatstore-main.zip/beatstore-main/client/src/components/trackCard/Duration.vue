<template>
  <span>{{ duration }}</span>
</template>
<script>
export default {
  props: ['duration'],
}
</script>

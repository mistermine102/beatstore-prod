<template>
  <h3 class="text-xl">
    <router-link :to="trackUrl">{{ title }}</router-link>
  </h3>
</template>
<script>
export default {
  props: ['title', 'trackUrl'],
}
</script>

<template>
  <router-link :to="'/profile/' + author._id" class="base-link">Author: {{ author.username }}</router-link>
</template>
<script>
export default {
  props: ['author'],
}
</script>

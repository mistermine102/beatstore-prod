<template>
  <span class="text-lg">{{ price }} {{ currency }} </span>
</template>
<script>
export default {
  props: ['price', 'currency'],
}
</script>

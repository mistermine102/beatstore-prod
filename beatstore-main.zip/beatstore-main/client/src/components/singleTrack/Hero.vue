<template>
  <div class="bg-grey rounded-regular mb-8 p-4 flex gap-8 shadow-lg">
    <img v-if="track.image" :src="track.image.url" :alt="track.image.alt" class="rounded-md" />
    <div class="py-4">
      <h2 class="text-left text-4xl mb-2">{{ track.title }}</h2>
      <p class="text-xl text-textLightGrey mb-4">{{ track.author.username }}</p>
      <div v-if="playable">
        <Duration></Duration>
        <div class="flex items-center gap-4">
          <PlayPauseBtn :track="track" class="-ml-2"></PlayPauseBtn>
          <div class="w-[600px] h-[100px] bg-background rounded-regular"></div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import PlayPauseBtn from '../track/PlayPauseBtn.vue'
import Duration from './Duration.vue'

export default {
  props: ['track', 'playable'],
  components: {
    PlayPauseBtn,
    Duration,
  },
}
</script>

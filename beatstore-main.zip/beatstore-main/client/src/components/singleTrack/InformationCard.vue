<template>
  <div>
    <BaseModalControls
      v-if="isModalVisible"
      :acceptBtnClasses="['bg-red-500']"
      :closeBtnClasses="['border-grey']"
      acceptBtnCaption="Delete"
      @close="isModalVisible = false"
      @accept="deleteTrack"
    >
      <p class="text-center mb-8 text-lg">Are you sure you want to delete?</p>
    </BaseModalControls>
    <div class="flex justify-between bg-grey rounded-regular shadow-lg p-4">
      <div class="flex flex-col gap-8">
        <Attributes :attributes="attributes"></Attributes>
        <div class="flex gap-16">
          <span v-if="track.totalStreams !== null && track.totalStreams !== undefined" class="flex gap-2">
            <PlayIcon strokeWidth="1.5" size="24" />{{ track.totalStreams }}</span
          >
          <Likes
            v-if="track.totalLikes !== null && track.totalLikes !== undefined"
            @like="likeTrack"
            :totalLikes="track.totalLikes"
            :isLiked="track.isLiked"
          ></Likes>
        </div>
      </div>
      <div class="flex flex-col gap-4">
        <div class="flex justify-end">
          <SettingsDropdown v-if="user && user._id === track.author._id" @deleteBeat="askForDelete" />
        </div>
        <Price v-if="track.price" :price="track.price.value" :currency="track.price.currency" class="w-fit"></Price>
      </div>
    </div>
  </div>
</template>
<script>
import PlayIcon from '../icons/Play.vue'
import Likes from '../Likes.vue'
import Price from './Price.vue'
import Attributes from './Attributes.vue'
import SettingsDropdown from './SettingsDropdown.vue'
import BaseModalControls from '../base/BaseModalControls.vue'

export default {
  props: ['track', 'attributes'],
  emits: ['deleteTrack', 'likeTrack'],
  components: {
    PlayIcon,
    Likes,
    Price,
    Attributes,
    SettingsDropdown,
    BaseModalControls,
  },
  data() {
    return {
      isModalVisible: false,
    }
  },
  methods: {
    askForDelete() {
      this.isModalVisible = true
    },
    deleteTrack() {
      this.$emit('deleteTrack')
    },
    likeTrack() {
      this.$emit('likeTrack')
    },
  },
  computed: {
    user() {
      return this.$store.state.user
    },
  },
}
</script>

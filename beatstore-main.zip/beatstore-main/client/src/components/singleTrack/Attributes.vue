<template>
  <div class="flex items-center gap-16">
    <p v-for="[key, value] of Object.entries(attributes)" :key="key">
      <span>{{ key }}</span> <span>{{ value }}</span>
    </p>
  </div>
</template>

<script>
export default {
  props: ['attributes'],
}
</script>

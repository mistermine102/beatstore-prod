<template>
    <p class="text-center mb-4">3:17</p>
</template>
<template>
  <div class="flex flex-col items-center gap-2">
    <p class="flex gap-1 items-center justify-center">
      <span class="text-lg">{{ price }}</span>
      <span class="text-sm text-textPrimary"> {{ currency }}</span>
    </p>
    <button class="base-btn-alt">Buy</button>
  </div>
</template>
<script>
export default {
  props: ['price', 'currency'],
}
</script>

<template>
  <Menu as="div" class="relative inline-block text-left">
    <div>
      <MenuButton>
        <GearIcon size="24" />
      </MenuButton>
    </div>

    <transition
      enter-active-class="transition ease-out duration-100"
      enter-from-class="transform opacity-0 scale-95"
      enter-to-class="transform opacity-100 scale-100"
      leave-active-class="transition ease-in duration-75"
      leave-from-class="transform opacity-100 scale-100"
      leave-to-class="transform opacity-0 scale-95"
    >
      <MenuItems
        class="absolute right-0 z-10 mt-2 w-56 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
      >
        <div class="py-1">
          <MenuItem v-slot="{ active }">
            <button
              @click="deleteBeat"
              :class="[active ? 'bg-gray-100 text-gray-900' : 'text-gray-700', 'flex items-center gap-2 px-4 py-2 text-sm w-full text-left']"
            >
              <TrashIcon class="text-red-600" size="24" />
              <span>Delete</span>
            </button>
          </MenuItem>
        </div>
      </MenuItems>
    </transition>
  </Menu>
</template>
<script>
import { Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/vue'
import GearIcon from '../icons/Gear.vue'
import TrashIcon from '../icons/Trash.vue'

export default {
  emits: ['deleteBeat'],
  components: {
    Menu,
    MenuButton,
    MenuItem,
    MenuItems,
    GearIcon,
    TrashIcon,
  },
  methods: {
    deleteBeat() {
      this.$emit('deleteBeat')
    },
  },
}
</script>

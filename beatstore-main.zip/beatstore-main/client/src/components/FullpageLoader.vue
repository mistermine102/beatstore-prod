<template>
  <div class="absolute inset-0 flex justify-center items-center">
    <div class="loader"></div>
  </div>
</template>

<template>
  <footer class="px-8 py-8 border-t border-grey font-light text-gray-300 mt-16">
    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptatum consectetur odio quam culpa at tenetur amet eveniet maiores, nostrum,
    cupiditate rem nulla, a aspernatur ab et recusandae modi quae officia!
  </footer>
</template>

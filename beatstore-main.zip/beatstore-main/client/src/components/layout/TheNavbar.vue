<template>
  <header class="fixed z-[1] top-0 right-0 left-0 bg-transparent">
    <nav class="flex justify-end p-4 items-center">
      <ul class="flex items-center gap-4">
        <li><router-link to="/">Home</router-link></li>
        <li><router-link v-if="user" to="/upload">Upload</router-link></li>
      </ul>
      <div class="ml-8">
        <div v-if="user" class="flex gap-2">
          <span>Welcome {{ user.username }}</span>
          <button @click="this.$store.dispatch('logout')" class="base-link">Logout</button>
        </div>
        <router-link v-else class="base-btn-alt" to="/login">Login</router-link>
      </div>
    </nav>
  </header>
</template>

<script>
export default {
  computed: {
    user() {
      return this.$store.state.user
    },
  },
}
</script>

<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    :width="size"
    :height="size"
    viewBox="0 0 24 24"
    :fill="fill ? 'white' : 'none'"
    stroke="currentColor"
    :stroke-width="strokeWidth"
    stroke-linecap="round"
    stroke-linejoin="round"
    class="ai ai-CircleCheck"
  >
    <path d="M8 12.5l3 3 5-6" />
    <circle cx="12" cy="12" r="10" />
  </svg>
</template>
<script>
export default {
  props: {
    strokeWidth: {
      type: String,
      defualt: '2',
    },
    size: {
      type: String,
      defualt: '32',
    },
    fill: {
      type: Boolean,
      default: false,
    },
  },
}
</script>

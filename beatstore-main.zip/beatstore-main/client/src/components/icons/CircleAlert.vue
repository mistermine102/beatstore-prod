<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    :width="size"
    :height="size"
    viewBox="0 0 24 24"
    :fill="fill ? 'white' : 'none'"
    stroke="currentColor"
    :stroke-width="strokeWidth"
    stroke-linecap="round"
    stroke-linejoin="round"
    class="ai ai-CircleAlert"
  >
    <circle cx="12" cy="12" r="10" />
    <path d="M12 7v6m0 3.5v.5" />
  </svg>
</template>
<script>
export default {
  props: {
    strokeWidth: {
      type: String,
      defualt: '2',
    },
    size: {
      type: String,
      defualt: '32',
    },
    fill: {
      type: Boolean,
      default: false,
    },
  },
}
</script>

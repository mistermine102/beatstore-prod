<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    :width="size"
    :height="size"
    viewBox="0 0 24 24"
    :fill="fill ? 'white' : 'none'"
    stroke="currentColor"
    :stroke-width="strokeWidth"
    stroke-linecap="round"
    stroke-linejoin="round"
    class="ai ai-ShareBox"
  >
    <path d="M12 3v12m0-12L8 7m4-4l4 4" />
    <path d="M2 17l.621 2.485A2 2 0 0 0 4.561 21H19.439a2 2 0 0 0 1.94-1.515L22 17" />
  </svg>
</template>
<script>
export default {
  props: {
    strokeWidth: {
      type: String,
      defualt: '2',
    },
    size: {
      type: String,
      defualt: '32',
    },
    fill: {
      type: Boolean,
      default: false,
    },
  },
}
</script>

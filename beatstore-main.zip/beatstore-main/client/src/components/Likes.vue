<template>
  <div class="flex gap-2">
    <button @click="like">
      <HeartIcon :fill="isLiked ? true : false" size="24" />
    </button>
    <span>{{ totalLikes }}</span>
  </div>
</template>
<script>
import HeartIcon from '../components/icons/Heart.vue'

export default {
  props: ['totalLikes', 'isLiked'],
  emits: ['like'],
  components: {
    HeartIcon,
  },
  methods: {
    like() {
      this.$emit('like')
    },
  },
}
</script>

<template>
  <div v-if="alert.isOpen" class="bg-grey z-[2] p-4 fixed top-2 right-2 w-fit rounded-regular">
    <div class="flex justify-between items-center gap-4">
      <div v-if="alert.type === 'info'" class="text-blue-500">
        <CircleAlertIcon size="32" />
      </div>
      <div v-if="alert.type === 'success'" class="text-green-500">
        <CircleCheckIcon size="32" />
      </div>
      <div v-if="alert.type === 'error'" class="text-red-500">
        <CircleXIcon size="32" />
      </div>
      <h3>{{ alert.title }}</h3>
    </div>
    <p>{{ alert.message }}</p>
  </div>
</template>
<script>
import CircleAlertIcon from './icons/CircleAlert.vue'
import CircleCheckIcon from './icons/CircleCheck.vue'
import CircleXIcon from './icons/CircleX.vue'

export default {
  components: {
    CircleAlertIcon,
    CircleCheckIcon,
    CircleXIcon,
  },
  computed: {
    alert() {
      return this.$store.state.alert
    },
  },
}
</script>

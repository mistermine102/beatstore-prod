<template>
  <div class="fixed bottom-0 w-full bg-darkGrey py-4">
    <div></div>
    <div class="flex flex-col items-center">
      <button v-if="isPaused" @click="playAudio">
        <PlayIcon size="32" />
      </button>
      <button v-else @click="pauseAudio">
        <PauseIcon size="32" />
      </button>
      <div class="grid grid-cols-3 gap-16">
        <p class="text-nowrap w-full text-center">{{ currentlyPlayingTrack.title }}</p>
        <div class="flex items-center">
          <span class="w-[50px] flex justify-center">{{ currentTimeInMinutes }}</span>
          <div class="w-[500px]">
            <BaseRangeInput :percentage="percentage" @percentageChange="handlePercentageChange" />
          </div>
          <span class="w-[50px] flex justify-center">{{ durationInMinutes }}</span>
        </div>
        <div class="flex justify-center items-center gap-4">
          <button @click="toggleMute">
            <SoundOnIcon v-if="volume !== 0" size="24"></SoundOnIcon>
            <SoundOffIcon v-else size="24"></SoundOffIcon>
          </button>
          <BaseRangeInput :percentage="volume" @percentageChange="changeVolume" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import PlayIcon from '../components/icons/Play.vue'
import PauseIcon from '../components/icons/Pause.vue'
import SoundOnIcon from './icons/SoundOn.vue'
import SoundOffIcon from './icons/SoundOff.vue'

import BaseRangeInput from './base/BaseRangeInput.vue'

export default {
  components: {
    PlayIcon,
    PauseIcon,
    BaseRangeInput,
    SoundOnIcon,
    SoundOffIcon,
  },
  data() {
    return {
      audio: null,
      currentTime: 0,
      duration: 0,
      previousVolume: 0,
      volume: 5,
      percentage: 0,
    }
  },
  methods: {
    handlePercentageChange(percentage) {
      this.currentTime = (this.duration * percentage) / 100
      this.changeCurrentTime()
    },
    changeCurrentTime() {
      if (!this.isPaused) {
        this.audio.pause()
        this.audio.currentTime = this.currentTime
        setTimeout(() => {
          this.audio.play()
        }, 300)
      } else {
        this.audio.currentTime = this.currentTime
      }
      this.percentage = (this.currentTime / this.duration) * 100
    },
    changeVolume(volume) {
      this.volume = volume
      this.audio.volume = volume / 100
    },
    playAudio() {
      this.$store.commit('setCurrentlyPlaying', { isPaused: false })
    },
    pauseAudio() {
      this.$store.commit('setCurrentlyPlaying', { isPaused: true })
    },
    toggleMute() {
      if (this.volume !== 0) {
        this.previousVolume = this.volume
        this.audio.volume = 0
        this.volume = 0
      } else {
        this.audio.volume = this.previousVolume / 100
        this.volume = this.previousVolume
      }
    },
  },
  computed: {
    currentTimeInMinutes() {
      let minutes = Math.floor(this.currentTime / 60)
      let seconds = (this.currentTime % 60).toFixed(0)

      if (seconds < 10) {
        seconds = '0' + seconds
      }

      return minutes + ':' + seconds
    },
    durationInMinutes() {
      let minutes = Math.floor(this.duration / 60)
      let seconds = (this.duration % 60).toFixed(0)

      if (seconds < 10) {
        seconds = '0' + seconds
      }

      return minutes + ':' + seconds
    },
    currentlyPlayingTrack() {
      return this.$store.state.currentlyPlaying.track
    },
    isPaused() {
      return this.$store.state.currentlyPlaying.isPaused
    },
  },
  watch: {
    currentlyPlayingTrack(newValue) {
      this.audio.src = newValue.audio.url
      this.audio.play()
    },
    isPaused(newValue) {
      if (newValue) {
        //pasued
        this.audio.pause()
      } else {
        //played
        this.audio.play()
      }
    },
  },
  mounted() {
    this.audio = new Audio(this.currentlyPlayingTrack.audio.url)

    this.audio.addEventListener('loadeddata', () => {
      //update currentTime in real time
      this.audio.addEventListener('timeupdate', () => {
        this.currentTime = this.audio.currentTime
        this.percentage = (this.currentTime / this.duration) * 100
      })

      this.duration = this.audio.duration
      this.audio.volume = this.volume / 100

      //play
      this.audio.play()
    })

    //key press event listeners
    document.addEventListener('keydown', e => {
      if (e.key === ' ') {
        if (this.isPaused) {
          this.playAudio()
        } else {
          this.pauseAudio()
        }
      }
    })
  },
  beforeUnmount() {
    this.audio.pause()
    this.audio.src = null
  },
}
</script>

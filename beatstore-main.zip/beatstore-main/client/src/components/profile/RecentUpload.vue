<template>
  <div class="base-container">
    <h2 class="base-heading mb-4">Recent upload</h2>
    <div v-if="isLoading" class="flex justify-center">
      <div class="loader"></div>
    </div>
    <Track v-else :track="track"></Track>
  </div>
</template>
<script>
import Track from '../trackCard/Track.vue'

export default {
  props: ['track', 'isLoading'],
  components: {
    Track,
  },
}
</script>

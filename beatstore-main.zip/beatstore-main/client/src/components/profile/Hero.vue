<template>
  <div class="base-container flex mb-8">
    <div class="w-[300px] h-[300px] bg-textLightGrey rounded-regular"></div>
    <div class="ml-4 flex flex-col justify-between flex-1 py-4">
      <div>
        <h2 class="text-left text-4xl mb-1">mistermine102</h2>
        <p class="mb-4 text-textLightGrey">Joined 28.07.2024</p>
        <button class="base-btn-alt">Follow</button>
      </div>
      <div class="grid grid-cols-3 gap-8">
        <div class="bg-gradient-to-br from-black to-darkGrey p-4 rounded-regular">
          <p>Followers</p>
          <p class="text-3xl font-semibold text-textPrimary">2020</p>
        </div>
        <div class="bg-gradient-to-br from-black to-darkGrey p-4 rounded-regular">
          <p>Total songs</p>
          <p class="text-3xl font-semibold text-textPrimary">24</p>
        </div>
        <div class="bg-gradient-to-br from-black to-darkGrey p-4 rounded-regular">
          <p>Specification</p>
          <p class="text-3xl font-semibold text-textPrimary">Trap</p>
        </div>
      </div>
    </div>
  </div>
</template>

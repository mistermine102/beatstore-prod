import axios from 'axios'
import store from './store'

export const interceptorsSetup = () => {
  axios.interceptors.request.use(
    config => {
      //append token to every request
      const token = store.state.token

      if (token) {
        config.headers.Authorization = 'Bearer ' + store.state.token
      }

      return config
    },
    error => {
      return Promise.reject(error)
    }
  )
}

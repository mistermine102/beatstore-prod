import { createStore } from 'vuex'
import router from './router'

const store = createStore({
  state() {
    return {
      serverUrl: 'http://localhost:3000',
      user: null,
      token: null,
      currentlyPlaying: {
        track: null,
        isPaused: false,
      },
      alert: {
        isOpen: false,
        success: 'info',
        title: '',
        message: '',
      },
    }
  },
  mutations: {
    toggleAlert(state) {
      state.alert.isOpen = !state.alert.isOpen
    },
    setAlert(state, payload) {
      const { type, title, message } = payload

      state.alert = {
        type,
        title,
        message,
      }
    },
    clearAlert(state) {
      state.alert = {
        type: 'info',
        title: 'test',
        message: 'test',
      }
    },
    setCurrentlyPlaying(state, payload) {
      if (payload.track && payload.track._id !== state.currentlyPlaying.track?._id) {
        state.currentlyPlaying.track = payload.track
      }
      state.currentlyPlaying.isPaused = payload.isPaused
    },
    setUser(state, user) {
      state.user = user
    },
    setToken(state, token) {
      state.token = token
    },
    clearUser(state) {
      state.user = null
    }
  },
  actions: {
    showAlert(ctx, payload) {
      const { type, title, message } = payload

      ctx.commit('setAlert', {
        type,
        title,
        message,
      })

      ctx.commit('toggleAlert')

      setTimeout(() => {
        ctx.commit('toggleAlert')
        ctx.commit('clearAlert')
      }, 3000)
    },
    login(ctx, payload) {
      ctx.commit('setUser', payload.user)
      ctx.commit('setToken', payload.token)

      localStorage.setItem('token', payload.token)

      router.push('/')
    },
    logout(ctx) {
      ctx.commit('clearUser')
      ctx.commit('setToken', null)
      localStorage.removeItem('token')
      
      router.push('/')
    }
  },
})

export default store

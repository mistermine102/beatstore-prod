import { createWebHistory, createRouter } from 'vue-router'
import store from './store'

const routes = [
  { path: '/', component: () => import('./views/Frontpage.vue') },
  { path: '/login', component: () => import('./views/Login.vue') },
  { path: '/register', component: () => import('./views/Register.vue') },
  { path: '/upload', component: () => import('./views/Upload.vue') },
  { path: '/beat/:id', component: () => import('./views/SingleBeat.vue') },
  { path: '/sample/:id', component: () => import('./views/SingleSample.vue') },
  { path: '/drumkit/:id', component: () => import('./views/SingleDrumkit.vue') },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// router.beforeEach((to, from) => {
//   if (to.path === '/upload' && !store.state.user) return { path: '/' }
// })

export default router

class Price {
  constructor({ value, currency }) {
    this.value = value || 0
    this.currency = currency || ''
  }
}

export default Price

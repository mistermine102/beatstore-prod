class Audio {
  constructor({ filename, duration }) {
    this.filename = filename || ''
    this.duration = duration || 0
  }
}

export default Audio

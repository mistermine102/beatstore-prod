import mongoose from 'mongoose'
import { Schema } from 'mongoose'

const schema = new Schema({
  username: String,
  email: String,
  password: String,
})
const User = mongoose.model('User', schema)

export default User

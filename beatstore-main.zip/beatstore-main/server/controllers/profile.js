import User from '../models/User.js'
import alterTrackData from '../alterTrackData.js'

export const getProfile = async (req, res) => {
  const { id: userId } = req.params

  const user = await User.findById(userId)
    .populate({
      path: 'recentUpload.trackId',
      populate: 'author',
    })
    .populate({
      path: 'uploads.trackId',
      populate: 'author',
    })

  const { createdAt, recentUpload, uploads, username, _id } = user._doc

  //modify recent upload
  const modifiedRecentUpload = await alterTrackData(recentUpload.trackId)

  //modify uploads
  const modifiedUploads = []

  for (const track of uploads) {
    const modifiedUpload = await alterTrackData(track.trackId)
    modifiedUploads.push(modifiedUpload)
  }

  const userDoc = {
    createdAt,
    recentUpload: modifiedRecentUpload,
    uploads: modifiedUploads,
    username,
    _id,
  }

  res.send({ user: userDoc })
}

import Beat from '../models/Beat.js'
import Sample from '../models/Sample.js'
import Drumkit from '../models/Drumkit.js'

export const toggleBeatLike = async (req, res, next) => {
  const { id } = req.params
  const beat = await Beat.findById(id)

  req.trackType = 'Beat'
  req.track = beat
  req.collectionName = 'beats'

  next()
}

export const toggleSampleLike = async (req, res, next) => {
  const { id } = req.params
  const sample = await Sample.findById(id)

  req.trackType = 'Sample'
  req.track = sample
  req.collectionName = 'samples'

  next()
}

export const toggleDrumkitLike = async (req, res, next) => {
  const { id } = req.params
  const drumkit = await Drumkit.findById(id)

  req.trackType = 'Drumkit'
  req.track = drumkit
  req.collectionName = 'drumkits'

  next()
}

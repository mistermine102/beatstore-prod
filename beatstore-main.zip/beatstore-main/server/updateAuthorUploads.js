import User from './models/User.js'

export const updateUploadsOnCreate = async (userId, trackType, trackId) => {
  const author = await User.findById(userId)

  author.uploads.push({
    createdAt: new Date(),
    trackType,
    trackId,
  })

  author.recentUpload = {
    trackType,
    trackId,
  }

  await author.save()
}

export const updateUploadsOnDelete = async (userId, trackType, trackId) => {
  const user = await User.findById(userId)

  user.uploads = user.uploads.filter(track => !track.trackId.equals(trackId) && track.trackType !== trackType)

  // check if deleted beat is author's recent upload
  if (user.recentUpload.trackId.equals(trackId)) {
    if (!user.uploads.length) {
      user.recentUpload = null
    } else {
      user.uploads.sort((a, b) => a.createdAt - b.createdAt)
      user.recentUpload = {
        trackType,
        trackId: user.uploads[0].trackId,
      }
    }
  }

  user.recentUpload = null

  await user.save()
}
